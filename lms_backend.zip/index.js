import http from 'http';
import { Server } from 'socket.io';
import app from './app.js';
import dotenv from 'dotenv';
import { connectToDatabase } from './db/connect.js';
import { ServerConfig } from './config/server.config.js';
import { initRedis } from './config/redisClient.js';
import videoSocketHandler from './sockets/videoSocketHandler.js';
import jwt from 'jsonwebtoken';
import Message from './models/Message.js';
import GroupMessage from './models/GroupMessage.js';
import GroupChatRoom from './models/GroupChatRoom.js';

dotenv.config();

// Create the HTTP server for Express and Socket.io
const server = http.createServer(app);

// Configure Socket.io with CORS
const io = new Server(server, {
  cors: {
    origin: [
      "http://localhost:5173",
      "https://edrilla.com"
    ],
    methods: ['GET', 'POST'],
    credentials: true
  },
  transports: ['websocket']
});

// Socket.io Authentication Middleware
const onlineUsers = new Map(); // Map userId to socketId

io.use((socket, next) => {
  try {
    const decoded = jwt.verify(
      socket.handshake.auth.token,
      process.env.JWT_ACCESS_TOKEN_SECRET_KEY
    );
    socket.user = decoded;
    socket.emit("authenticated", { userId: decoded._id });
    next();
  } catch (err) {
    socket.emit("auth_error", "Invalid token");
    next(new Error("Authentication error: Invalid token"));
  }
});

// Handle socket connections
io.on('connection', (socket) => {
  //console.log(`✅ Socket connected: ${socket.id}, User: ${socket.user._id}`);

  onlineUsers.set(socket.user?._id?.toString(), socket.id);

  socket.join(socket.user?._id?.toString());

  // Join all group chat rooms the user is part of
  (async () => {
    try {
      const userGroupRooms = await GroupChatRoom.find({ participants: socket.user._id }).select('_id');
      userGroupRooms.forEach((groupRoom) => {
        socket.join(groupRoom._id.toString());
        //console.log(`User ${socket.user._id} joined group room ${groupRoom._id}`);
      });
    } catch (err) {
      console.error('Error joining group rooms for user:', socket.user._id, err);
    }
  })();

  io.emit('userOnline', { userId: socket.user._id });

  videoSocketHandler(socket);

  // One-on-one message events (unchanged)
  socket.on('sendMessage', async (data) => {
    try {
      const { roomId, receiverId, message } = data;
      if (!roomId || !receiverId || !message) {
        return socket.emit('error', { message: 'Missing required fields: roomId, receiverId, message' });
      }

      const newMessage = await Message.create({
        chatRoomId: roomId,
        sender: socket.user._id,
        receiver: receiverId,
        message
      });

      const receiverSocketId = onlineUsers.get(receiverId.toString());
      if (receiverSocketId) {
        io.to(receiverSocketId).emit('newMessage', newMessage);
      }

      socket.emit('messageSent', newMessage);
    } catch (err) {
      socket.emit('error', { message: err.message });
    }
  });

  socket.on('messageRead', async (data) => {
    try {
      const { roomId, messageId } = data;
      if (!roomId || !messageId) {
        return socket.emit('error', { message: 'Missing required fields: roomId, messageId' });
      }

      const message = await Message.findOneAndUpdate(
        { _id: messageId, chatRoomId: roomId, receiver: socket.user._id },
        { isRead: true },
        { new: true }
      );

      if (!message) {
        return socket.emit('error', { message: 'Message not found or not authorized' });
      }

      const senderSocketId = onlineUsers.get(message.sender.toString());
      if (senderSocketId) {
        io.to(senderSocketId).emit('messageRead', { messageId });
      }
    } catch (err) {
      socket.emit('error', { message: err.message });
    }
  });

  // Group message events (new)
  socket.on('sendGroupMessage', async (data) => {
    try {
      const { groupRoomId, message } = data;
      if (!groupRoomId || !message) {
        return socket.emit('error', { message: 'Missing required fields: groupRoomId, message' });
      }

      const groupRoom = await GroupChatRoom.findOne({
        _id: groupRoomId,
        participants: socket.user._id
      });

      if (!groupRoom) {
        return socket.emit('error', { message: 'Not authorized to send message in this group chat room' });
      }

      const newGroupMessage = await GroupMessage.create({
        groupChatRoomId: groupRoomId,
        sender: socket.user._id,
        message,
        readBy: [socket.user._id]
      });


      //console.log('sendGroupMessage: New message created', { messageId: newGroupMessage._id, groupRoomId, sender: socket.user._id });

      io.to(groupRoomId.toString()).emit('newGroupMessage', newGroupMessage);
    } catch (err) {
      socket.emit('error', { message: err.message });
    }
  });

  socket.on('markGroupMessagesRead', async (data) => {
    try {
      const { groupRoomId } = data;
      if (!groupRoomId) {
        return socket.emit('error', { message: 'Missing required field: groupRoomId' });
      }

      const groupRoom = await GroupChatRoom.findOne({
        _id: groupRoomId,
        participants: socket.user._id
      });

      if (!groupRoom) {
        return socket.emit('error', { message: 'Not authorized to mark messages in this group chat room' });
      }

      const updateResult = await GroupMessage.updateMany(
        {
          groupChatRoomId: groupRoomId,
          readBy: { $ne: socket.user._id }
        },
        { $addToSet: { readBy: socket.user._id } }
      );

      io.to(groupRoomId.toString()).emit('groupMessagesRead', {
        userId: socket.user._id,
        modifiedCount: updateResult.modifiedCount
      });
    } catch (err) {
      socket.emit('error', { message: err.message });
    }
  });

  socket.on('disconnect', () => {
    //console.log(`❌ Socket disconnected: ${socket.id}, User: ${socket.user?._id}`);
    onlineUsers.delete(socket.user?._id?.toString());
    io.emit('userOffline', { userId: socket.user?._id });
  });
});

// Start server and initialize DB + Redis
const PORT = process.env.PORT || ServerConfig.port || 4000;

server.listen(PORT, async () => {
  try {
    await connectToDatabase();
    await initRedis();
    //console.log(`🚀 Server + WebSocket running on port ${PORT}`);
  } catch (error) {
    console.error('❌ Error starting server:', error);
    process.exit(1);
  }
});