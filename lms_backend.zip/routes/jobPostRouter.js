import express from 'express';
import {
  createJobPost,
  getAllJobPosts,
  getJobPostById,
  updateJobPost,
  deleteJobPost,
  submitProposal,
  getMyJobPosts
} from '../controllers/jobPostController.js';
import accessTokenAutoRefresh from '../middlewares/accessTokenAutoRefresh.js';
import canManageJobPosts from '../middlewares/canManageJobPosts.js';
import { isAdmin } from '../middlewares/isAdmin.js';
import passport from 'passport';
import { upload } from '../middlewares/upload-middleware.js';

const router = express.Router();

// Public routes
router.get('/', getAllJobPosts);
router.get('/my-posts', accessTokenAutoRefresh, passport.authenticate('jwt', { session: false }), getMyJobPosts); // Moved before /:id
router.get('/:id', getJobPostById);

// Protected routes
router.use(accessTokenAutoRefresh);
router.use(passport.authenticate('jwt', { session: false }));

// Job post management
router.post('/', canManageJobPosts, upload.single('thumbnail'), createJobPost);
router.post('/:jobId/proposals', upload.single('cv'), submitProposal);
router.put('/:id', canManageJobPosts, upload.single('thumbnail'), updateJobPost);
router.delete('/:id', canManageJobPosts, deleteJobPost);

export default router;