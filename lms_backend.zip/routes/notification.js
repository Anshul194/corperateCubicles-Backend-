import express from "express";
import { getAllNotifications, markNotificationsRead,markNotificationsReadSingle,sendNotification} from "../controllers/notificationController.js";
import accessTokenAutoRefresh from "../middlewares/accessTokenAutoRefresh.js";
import passport from "passport";
import { isAdmin } from "../middlewares/isAdmin.js";
import { upload } from "../middlewares/upload-middleware.js";

const notificationRouter = express.Router();

// ✅ Get only logged-in user's unread notifications
notificationRouter.get(
  "/",
  accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  getAllNotifications
);
notificationRouter.put(
  "/mark-read",
  accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  markNotificationsRead
);


notificationRouter.put(
  "/mark-read/:id",
  accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  markNotificationsReadSingle
);

notificationRouter.post(
  "/send",
  accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  isAdmin,
  upload.single("image"), // single image upload
  sendNotification
);


export default notificationRouter;
