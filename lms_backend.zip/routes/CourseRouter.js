import express from 'express';
import multer from 'multer';
import { createCourse, getCourseById, getAllCourses, updateCourse, deleteCourse, getCourseContents, getCourseAttachments,getMyCourses,getCoursesByCategory,getCourseBySlug ,getAllCourseAttachments ,filterCourses, sortCourses, disableDripForUser } from '../controllers/CourseController.js';
// import { createCourse, getCourseById, getAllCourses, updateCourse, deleteCourse, getCourseContents, getCourseAttachments,getMyCourses  } from '../controllers/CourseController.js';
import accessTokenAutoRefresh from '../middlewares/accessTokenAutoRefresh.js';
import passport from 'passport';
import { isAdmin } from '../middlewares/isAdmin.js';
import isUserBanned from '../middlewares/isUserBanned.js';

const courseRouter = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Ensure this directory exists
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});
const upload = multer({ storage });


courseRouter.get(
  '/my-courses',
  accessTokenAutoRefresh,
  passport.authenticate('jwt', { session: false }),
  isUserBanned,
  getMyCourses
);

// Create a course (admin or instructor)
courseRouter.post(
  '/',
  accessTokenAutoRefresh,
  passport.authenticate('jwt', { session: false }),
  isAdmin,
  isUserBanned,
  upload.fields([
    { name: 'thumbnail', maxCount: 1 },
    { name: 'coverImage', maxCount: 1 },
    // { name: 'demoVideo', maxCount: 1 }
  ]),

  createCourse
);

// Get all courses (public)
courseRouter.get('/contents', getCourseContents);

courseRouter.get('/filter', filterCourses);

courseRouter.get('/sort', sortCourses);
// courseRouter.get('/', getAllCourses);
courseRouter.get(
  '/',
  (req, res, next) => {
    passport.authenticate('jwt', { session: false }, (err, user) => {
      if (user) req.user = user;
      next();
    })(req, res, next);
  },
  getAllCourses
);



// Get a course by ID (public)
courseRouter.get('/:id', getCourseById);

courseRouter.get('/slug/:slug', getCourseBySlug);

courseRouter.get('/category/:categoryId', getCoursesByCategory);



//:courseId/attachments?type=video
// Get course attachments by course ID (public)
courseRouter.get('/:courseId/attachments', getCourseAttachments);
courseRouter.get('/:courseId/all-attachments', getAllCourseAttachments);
// courseRouter.get('/:courseId/all-attachments-new', getAllCourseAttachmentsNested);


// Update a course (admin or instructor)
courseRouter.put(
  '/:id',
  accessTokenAutoRefresh,
  passport.authenticate('jwt', { session: false }),
  isAdmin,
  isUserBanned,
  upload.fields([
    { name: 'thumbnail', maxCount: 1 },
    { name: 'coverImage', maxCount: 1 },
  ]),
  updateCourse
);

// Delete a course (admin or instructor, soft delete)
courseRouter.delete(
  '/:id',
  accessTokenAutoRefresh,
  passport.authenticate('jwt', { session: false }),
  isAdmin,
  isUserBanned,
  deleteCourse
);

// Disable drip setting for a user on a course (admin/instructor only)
courseRouter.post(
  '/:courseId/disable-drip',
  accessTokenAutoRefresh,
  passport.authenticate('jwt', { session: false }),
  isAdmin,
  isUserBanned,
  disableDripForUser
);








export default courseRouter;