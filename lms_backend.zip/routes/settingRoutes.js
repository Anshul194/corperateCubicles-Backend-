import express from 'express';
import { getSettings, getAllSettings} from '../controllers/settingController.js';

const router = express.Router();

// POST /settings - Get settings by keys
router.post('/', getSettings);

router.get('/', getAllSettings);

export default router;