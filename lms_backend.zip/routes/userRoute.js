import express from 'express';
import { signup, updateProfile, login, getUserById, blockUser, changeUserPassword, forgotPassword, resetPassword, getMyProfile, deleteDocument, getUserDashboard, deleteUser, getOverviewDashboard, deleteEducation, createUserByAdmin, logoutAllSessions, updateFcmToken, sendTestNotification, banOrShadowBanUser, unbanUser,  listDeviceApprovalRequests,
  manageDeviceRequest, 
  searchUsers, sendOtpviaemail, verifyOtpviaemail, googleLogin } from '../controllers/userController.js';
import accessTokenAutoRefresh from '../middlewares/accessTokenAutoRefresh.js';
import { sendOtp, verifyOtp } from '../controllers/otpController.js';
import passport from 'passport';
import {upload} from '../middlewares/upload-middleware.js';
import { isAdmin } from '../middlewares/isAdmin.js';
import { validateResetPassword } from '../middlewares/validation.js';
import isUserBanned from '../middlewares/isUserBanned.js';

const userRouter = express.Router();


userRouter.post('/signup', signup);
userRouter.post('/forgot-password', forgotPassword);
//update-fcm-token
userRouter.post('/fcm/update', updateFcmToken);
//send-test-notification
userRouter.get('/send-test-notification', sendTestNotification);
  
userRouter.post('/reset-password', validateResetPassword, resetPassword);
// userRouter.post('/change-password', changeUserPassword);
userRouter.post('/change-password', accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  isUserBanned,
  changeUserPassword
);
userRouter.post(
  '/create-user',
  accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  isAdmin,
  createUserByAdmin
);



// profile update route
userRouter.get('/me',accessTokenAutoRefresh,passport.authenticate('jwt', { session: false }), isUserBanned, getMyProfile);
// userRouter.put('/profile',upload.single("profilePicture"), accessTokenAutoRefresh, passport.authenticate("jwt", { session: false }),updateProfile);
userRouter.put(
  '/profile',
  upload.fields([
    { name: 'profilePicture', maxCount: 1 },
    { name: 'documentation', maxCount: 5 } // or more, adjust as needed
  ]),
  accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  isUserBanned,
  updateProfile
);
userRouter.delete('/documentation/:documentId', 
  accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  isUserBanned,
  deleteDocument
);

userRouter.delete('/education/:educationId', 
  accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  isUserBanned,
  deleteEducation
);

userRouter.get("/search", accessTokenAutoRefresh, passport.authenticate("jwt", { session: false }), searchUsers);

userRouter.post('/login', login);
userRouter.get('/user', accessTokenAutoRefresh, passport.authenticate("jwt", { session: false }), isUserBanned, getUserById);
userRouter.put('/block-unblock', accessTokenAutoRefresh, passport.authenticate("jwt", { session: false }), isAdmin, blockUser);
userRouter.post('/send-otp', sendOtp);
userRouter.post('/verify-otp', verifyOtp);
userRouter.delete('/:id', accessTokenAutoRefresh, passport.authenticate('jwt', { session: false }), isUserBanned, deleteUser);
userRouter.get('/dashboard', accessTokenAutoRefresh, passport.authenticate('jwt', { session: false }), isUserBanned, getUserDashboard);
userRouter.get('/overview', accessTokenAutoRefresh, passport.authenticate('jwt', { session: false }), isAdmin, isUserBanned, getOverviewDashboard);
userRouter.post('/logout-all-sessions', accessTokenAutoRefresh, logoutAllSessions);
userRouter.put(
  '/ban-shadow-ban',
  accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  isAdmin,
  banOrShadowBanUser
);
userRouter.put(
  '/unban-user',
  accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  isAdmin,
  unbanUser
);

userRouter.get(
  '/device-approvals',
  accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  isAdmin,
  listDeviceApprovalRequests
);

userRouter.post(
  '/device-approvals/manage',
  accessTokenAutoRefresh,
  passport.authenticate("jwt", { session: false }),
  isAdmin,
  manageDeviceRequest
);


userRouter.post('/sendotp', sendOtpviaemail);
userRouter.post('/google-login', googleLogin);
userRouter.post('/verifyotp', verifyOtpviaemail);


export default userRouter;