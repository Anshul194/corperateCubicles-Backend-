import express from 'express';
import {
  addTestimonialAdmin,
  listTestimonialsAdmin,
  updateTestimonialAdmin,
  deleteTestimonialAdmin,
  submitTestimonial,
  getApprovedTestimonials,
  getTestimonial
} from '../controllers/testimonialController.js';

const router = express.Router();

// Admin routes (add your admin auth middleware as needed)
router.post('/admin/testimonials', addTestimonialAdmin);
router.get('/admin/testimonials', listTestimonialsAdmin);
router.patch('/admin/testimonials/:id', updateTestimonialAdmin);
router.delete('/admin/testimonials/:id', deleteTestimonialAdmin);

// User routes (add your user auth middleware as needed)
router.post('/testimonials', submitTestimonial);
router.get('/testimonials', getApprovedTestimonials);
router.get('/testimonials/:id', getTestimonial);

export default router;