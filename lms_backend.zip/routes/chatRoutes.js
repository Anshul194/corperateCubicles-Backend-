import express from 'express';
import {
  createOrGetChatRoom,
  getAllChatRooms,
  getMessages,
  sendMessage,
  markMessagesAsRead,
  createOrGetGroupChatRoom,
  getAllGroupChatRooms,
  getGroupMessages,
  sendGroupMessage,
  markGroupMessagesAsRead
} from '../controllers/chatController.js';
import accessTokenAutoRefresh from '../middlewares/accessTokenAutoRefresh.js';
import passport from 'passport';

const router = express.Router();

// Debug middleware to log req.user before routes
router.use((req, res, next) => {
  //console.log('chatRoutes: Entering middleware', {
    user: req.user,
    headers: {
      authorization: req.headers.authorization,
      'x-access-token': req.headers['x-access-token'],
      'x-refresh-token': req.headers['x-refresh-token']
    },
    cookies: req.cookies
  });
  next();
});

// Apply JWT authentication
router.use(accessTokenAutoRefresh);
router.use(passport.authenticate('jwt', { session: false }));

// Chat API endpoints
router.post('/room', createOrGetChatRoom); // POST /chat/room
router.get('/rooms', getAllChatRooms); // GET /chat/rooms
router.get('/messages/:roomId', getMessages); // GET /chat/messages/:roomId
router.post('/message', sendMessage); // POST /chat/message
router.patch('/message/read', markMessagesAsRead); // PATCH /chat/message/read


// Group Chat API endpoints (new)
router.post('/group/room', createOrGetGroupChatRoom); // POST /chat/group/room - body: { participants: [userId1, userId2, ...] } (excluding sender, min 2 for group)
router.get('/group/rooms', getAllGroupChatRooms); // GET /chat/group/rooms
router.get('/group/messages/:groupRoomId', getGroupMessages); // GET /chat/group/messages/:groupRoomId
router.post('/group/message', sendGroupMessage); // POST /chat/group/message - body: { groupRoomId, message }
router.patch('/group/message/read', markGroupMessagesAsRead); // PATCH /chat/group/message/read - body: { groupRoomId }

export default router;