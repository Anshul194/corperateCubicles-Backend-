import mongoose from "mongoose";

const { Schema } = mongoose;

const courseSchema = new mongoose.Schema({
  // Basic Info
  title: { type: String, required: true, trim: true },
  subtitle: { type: String, trim: true },
  slug: { type: String, required: true, unique: true, trim: true, lowercase: true },
  description: { type: String, trim: true },
  shortDescription: { type: String, trim: true},
  seoMetaDescription: { type: String, trim: true},
  seoContent: { type: String, trim: true},
  enrolledStudents: [{ type: Schema.Types.ObjectId, ref: 'User' }],
  // CHANGE: Removed default value of 20000, set to 0
  enrolledStudentsCount: { type: Number, default: 0 },
  
  // Media
  thumbnail: { type: String, trim: true },
  coverImage: { type: String, trim: true },
  demoVideo: { type: String, trim: true },
  
  // Classification
  categoryId: { type: Schema.Types.ObjectId, ref: 'CourseCategory'},
  subCategoryId: { type: Schema.Types.ObjectId, ref: 'SubCategory' },
  level: [{ type: String, enum: ['beginner', 'intermediate', 'advanced'], default: ['beginner'] }],
  modules: [{ type: Schema.Types.ObjectId, ref: 'Module' }],
  
  // Pricing - Handle empty strings for decimal fields
  price: { 
    type: mongoose.Types.Decimal128, 
    default: 0,
    set: function(value) {
      // Convert empty strings to 0
      if (value === '' || value === null || value === undefined) {
        return 0;
      }
      return value;
    }
  },
  salePrice: { 
    type: mongoose.Types.Decimal128, 
    default: 0,
    set: function(value) {
      // Convert empty strings to 0
      if (value === '' || value === null || value === undefined) {
        return 0;
      }
      return value;
    }
  },
  currency: { type: String, default: 'USD' },
  discountPrice: { 
    type: mongoose.Types.Decimal128,
    set: function(value) {
      // Convert empty strings to null for optional field
      if (value === '' || value === null || value === undefined) {
        return null;
      }
      return value;
    }
  },
  discountExpiry: { type: Date },
  
  // Course Details
  duration: { type: Number }, // in minutes
  totalLessons: { type: Number, default: 0 },
  instructorId: { type: Schema.Types.ObjectId, ref: 'User'},
  coInstructors: [{ type: Schema.Types.ObjectId, ref: 'User' }],
  
  // Enrollment & Access
  isPublished: { type: Boolean, default: true },
  enrollmentType: { type: String, enum: ['open', 'invite_only', 'paid', 'subscription'], default: 'open' },
  maxStudents: { type: Number },
  currentEnrollments: { type: Number, default: 0 },
  salesCount: { type: Number, default: 0 },
  revenue: { type: Number, default: 0 },
  
  // Learning Features
  tags: [{ type: String, trim: true }],
  prerequisites: { type: String, trim: true, default: 'None' },
  learningOutcomes: [{ type: String, trim: true }],
  completionCriteria: { 
    type: { type: String, enum: ['all_lessons', 'percentage', 'specific_lessons'], default: 'all_lessons' },
    value: { type: Number, default: 100 }, // percentage or specific count
    requiredLessons: [{ type: Schema.Types.ObjectId, ref: 'Lesson' }]
  },
  
  // Certificate & Downloads
  certificateTemplate: { type: String, trim: true },
  isDownloadable: { type: Boolean, default: false },
  downloadableFiles: [{ 
    name: { type: String, trim: true },
    url: { type: String, trim: true },
    size: { type: String, trim: true }
  }],
  
  // Community & Support
  courseForum: { type: Boolean, default: false },
  enableQA: { type: Boolean, default: true },
  enableReviews: { type: Boolean, default: true },
  
  // Access Control
  isPrivate: { type: Boolean, default: false },
  enableWaitlist: { type: Boolean, default: false },
  
  // Localization
  languages: [{ type: String, enum: ['English', 'Español', 'Português', 'हिन्दी', 'العربية', 'Français', 'Deutsch'], default: ['English'] }],
  
  // Additional Fields
  topic: [{ type: String, trim: true }],
  difficulty: { type: String, enum: ['easy', 'medium', 'hard'], default: 'medium' },
  requirements: [{ type: String, trim: true }],
  targetAudience: [{ type: String, trim: true }],
  
  // Analytics
  averageRating: { type: Number, default: 0, min: 0, max: 5 },
  totalReviews: { type: Number, default: 0 },
  totalViews: { type: Number, default: 0 },
  
  // Scheduling (for live courses/webinars)
  isLive: { type: Boolean, default: false },
  startDate: { type: Date },
  endDate: { type: Date },
  timeZone: { type: String, trim: true },
  meetingInfo: {
    platform: { type: String, enum: ['zoom', 'teams', 'meet', 'custom'] },
    meetingId: { type: String, trim: true },
    password: { type: String, trim: true },
    link: { type: String, trim: true }
  },
  popular: {
    type: Boolean,
    default: false
  },

  // Drip setting: users for whom drip is disabled
  dripSettingDisabledFor: [{ type: Schema.Types.ObjectId, ref: 'User', default: [] }],
  
  // Support & Misc
  support: { type: String, trim: true },
  faq: [{ 
    question: { type: String, trim: true },
    answer: { type: String, trim: true }
  }],
  
  // Soft Delete
  isDeleted: { type: Boolean, default: false },
  deletedAt: { type: Date, default: null }
}, { timestamps: true });

// Pre-save middleware to handle decimal field validation
courseSchema.pre('save', function(next) {
  // Handle price fields - convert empty strings to proper values
  if (this.price === '' || this.price === null || this.price === undefined) {
    this.price = 0;
  }
  if (this.salePrice === '' || this.salePrice === null || this.salePrice === undefined) {
    this.salePrice = 0;
  }
  if (this.discountPrice === '' || this.discountPrice === null || this.discountPrice === undefined) {
    this.discountPrice = null;
  }
  
  next();
});

// Pre-validate middleware to clean data before validation
courseSchema.pre('validate', function(next) {
  // Clean decimal fields
  if (this.price === '') this.price = 0;
  if (this.salePrice === '') this.salePrice = 0;
  if (this.discountPrice === '') this.discountPrice = undefined;
  
  next();
});

courseSchema.virtual('enrollstudent_course_details', {
  ref: 'Enrollment',
  localField: '_id',
  foreignField: 'courseId',
  justOne: false,
  match: { isActive: true },
});

// ➕ Enable virtuals in output
courseSchema.set('toObject', { virtuals: true });
courseSchema.set('toJSON', { virtuals: true });

// Indexes
courseSchema.index({ slug: 1 });
courseSchema.index({ categoryId: 1 });
courseSchema.index({ subCategoryId: 1 });
courseSchema.index({ instructorId: 1 });
courseSchema.index({ topic: 1 });
courseSchema.index({ isPublished: 1, isDeleted: 1 });
courseSchema.index({ startDate: 1, endDate: 1 });
courseSchema.index({ averageRating: -1 });

const Course = mongoose.models.Course || mongoose.model('Course', courseSchema);

export default Course;