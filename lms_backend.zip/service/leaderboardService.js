import LeaderboardSettings from '../models/LeaderboardSettings.js';
import Leaderboard from '../models/Leaderboard.js';
import LeaderboardHistory from '../models/LeaderboardHistory.js';
import User from '../models/user.js';

export async function getLatestSettings() {
  return await LeaderboardSettings.findOne().sort({ updatedAt: -1 });
}

export function getLevelFromXP(levelRanks, xp) {
  for (const rank of levelRanks) {
    if (xp >= rank.minXP && xp <= rank.maxXP) {
      return rank.levelName;
    }
  }
  return levelRanks.length ? levelRanks[levelRanks.length - 1].levelName : 'Unranked';
}

export async function updateLeaderboard({ userId, action, referenceType, referenceId, remark }) {
  const settings = await getLatestSettings();
  if (!settings) throw new Error('Leaderboard settings not configured');
  const xpChange = settings.actionXP.get(action) || 0;
  let leaderboard = await Leaderboard.findOne({ userId });
  if (!leaderboard) {
    leaderboard = new Leaderboard({ userId, xp: 0 });
  }
  leaderboard.xp += xpChange;
  leaderboard.level = getLevelFromXP(settings.levelRanks, leaderboard.xp);
  leaderboard.lastUpdated = new Date();
  await leaderboard.save();

  await LeaderboardHistory.create({
    userId,
    referenceType,
    referenceId,
    action,
    remark,
    xpChange,
    totalXP: leaderboard.xp
  });

  return leaderboard;
}

export async function getGlobalLeaderboard(limit = 50) {
  return await Leaderboard.find()
    .sort({ xp: -1 })
    .limit(limit)
    .populate('userId', 'name email');
}

export async function getUserLeaderboard(userId) {
  const entry = await Leaderboard.findOne({ userId }).populate('userId', 'name email');
  if (!entry) return null;
  const higherXPCount = await Leaderboard.countDocuments({ xp: { $gt: entry.xp } });
  return { ...entry.toObject(), rank: higherXPCount + 1 };
}

export async function getUserHistory(userId, limit = 100) {
  return await LeaderboardHistory.find({ userId })
    .sort({ createdAt: -1 })
    .limit(limit);
}

