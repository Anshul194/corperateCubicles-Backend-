import Testimonial from '../models/Testimonial.js';

const createTestimonial = async (data, isAdmin = false) => {
  if (isAdmin) {
    data.status = 'approved';
  } else {
    data.status = 'pending';
  }
  const testimonial = new Testimonial(data);
  return await testimonial.save();
};

const getTestimonials = async (filter = {}, options = {}) => {
  return await Testimonial.find(filter, null, options);
};

const getTestimonialById = async (id) => {
  return await Testimonial.findById(id);
};

const updateTestimonial = async (id, update) => {
  return await Testimonial.findByIdAndUpdate(id, update, { new: true });
};

const deleteTestimonial = async (id) => {
  return await Testimonial.findByIdAndDelete(id);
};

export default {
  createTestimonial,
  getTestimonials,
  getTestimonialById,
  updateTestimonial,
  deleteTestimonial
};