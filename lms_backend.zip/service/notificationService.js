import Notification from "../models/Notifications.js";
import FcmToken from "../models/fcmTokens.js";
import fcmService from "../utils/notificationService.js";
import Enrollment from "../models/CourseEnrollment.js";
import mongoose from "mongoose";

class NotificationService {

  async getAll(query, userId) {
    try {
      const { page = 1, limit = 10, sort = "{}" } = query;
      const pageNum = Math.max(parseInt(page) || 1, 1);
      const limitNum = Math.max(parseInt(limit) || 10, 1);
      const skip = (pageNum - 1) * limitNum;

      let parsedSort = {};
      try {
        parsedSort = JSON.parse(sort);
      } catch (err) {
        console.warn("⚠️ Invalid JSON for sort");
      }

      // ✅ Build match condition safely
      const matchConditions = {
        $or: [
          ...(userId ? [{ user_id: mongoose.isValidObjectId(userId) ? userId : new mongoose.Types.ObjectId(userId) }] : []),
          { user_id: null } // admin notifications
        ]
      };

      //console.log("🔍 Match conditions for notifications:", matchConditions);

      const pipeline = [{ $match: matchConditions }];

      // Sorting
      if (Object.keys(parsedSort).length > 0) {
        const sortStage = {};
        for (const [key, val] of Object.entries(parsedSort)) {
          sortStage[key] = val === "asc" ? 1 : -1;
        }
        pipeline.push({ $sort: sortStage });
      } else {
        pipeline.push({ $sort: { created_at: -1 } });
      }

      // Pagination
      pipeline.push({
        $facet: {
          data: [{ $skip: skip }, { $limit: limitNum }],
          count: [{ $count: "total" }],
        },
      });

      const [result] = await Notification.aggregate(pipeline);

      const notifications = result?.data || [];
      const total = result?.count[0]?.total || 0;

      //console.log(`📌 Notifications fetched: ${notifications.length}, Total: ${total}`);

      return {
        result: notifications,
        total,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(total / limitNum),
      };
    } catch (error) {
      console.error("❌ Error fetching notifications:", error.message);
      throw new Error("Cannot fetch notifications");
    }
  }



   async markAllRead(userId, deviceId) {
    try {
      const result = await Notification.updateMany(
        {
          $or: [
        { user_id: userId }
        // { device_id: deviceId }
          ],
          status: 0
        },
        { $set: { status: 1 } }
      );

      return {
        matched: result.matchedCount,
        modified: result.modifiedCount,
      };
    } catch (error) {
      console.error("❌ Error marking notifications as read:", error.message);
      throw new Error("Cannot mark notifications as read");
    }
  }

  //markSingleRead
  async markSingleRead(userId, notificationId) {
    try {
      const result = await Notification.updateOne(
        {
          user_id: userId,
          _id: notificationId,
          status: 0
        },
        { $set: { status: 1 } }
      );
      return {
        matched: result.matchedCount,
        modified: result.modifiedCount,
      };
    } catch (error) {
      console.error("❌ Error marking notification as read:", error.message);
      throw new Error("Cannot mark notification as read");
    } 
  }
  
async sendToAllStudents(data, webPushLink = null) {
  try {
    //console.log("🔥 sendToAllStudents called with data:", data);

    // 1️⃣ Fetch all FCM tokens
    const tokens = await FcmToken.find({}).select("token userId deviceId -_id");
    //console.log(`🟢 Total tokens fetched: ${tokens.length}`);

    if (!tokens || tokens.length === 0) {
      console.warn("⚠️ No students with FCM tokens found");
      return { success: false, message: "No students with FCM tokens found" };
    }

    let sent = 0;
    let failed = 0;

    // 2️⃣ Prepare notifications with proper user_id and device_id
    const notifications = tokens.map(t => ({
      user_id: t.userId || null,     // store actual userId or null if guest
      device_id: t.deviceId || null, // always store deviceId
      data,
      status: 0,
    }));

    // 3️⃣ Save notifications in bulk (fast)
    if (notifications.length > 0) {
      const result = await Notification.bulkWrite(
        notifications.map(n => ({ insertOne: { document: n } }))
      );
      //console.log("💾 Notifications saved in MongoDB:", result.insertedCount);
    }

    // 4️⃣ Send FCM notifications per token
    const sendPromises = tokens.map(async t => {
      if (!t.token) {
        console.warn(`⚠️ Skipping device ${t.deviceId} (no token)`);
        failed++;
        return;
      }

      try {
        const res = await fcmService.sendPushNotification([t.token], data, webPushLink);

        // Check response
        if (res.responses && res.responses[0]) {
          if (res.responses[0].success) {

            //save notification
            const notification = new Notification({
              user_id: t.userId || null,
              device_id: t.deviceId || null,
              data,
              status: 0,
            });
            await notification.save();

            sent++;
            //console.log(`✅ Notification sent to user: ${t.userId || "Guest"}, device: ${t.deviceId}`);
          } else {
            failed++;
            //console.log(`❌ Notification FAILED for user: ${t.userId || "Guest"}, device: ${t.deviceId}, error: ${res.responses[0].error?.message}`);

            // Remove invalid FCM token automatically
            if (res.responses[0].error?.code === "messaging/registration-token-not-registered") {
              await FcmToken.deleteOne({ token: t.token });
              //console.log(`🗑 Removed invalid token: ${t.token}`);
            }
          }
        } else {
          failed++;
          console.warn(`⚠️ Unknown FCM response for user: ${t.userId || "Guest"}, device: ${t.deviceId}`);
        }
      } catch (err) {
        failed++;
        console.error(`❌ FCM ERROR for user: ${t.userId || "Guest"}, device: ${t.deviceId}`, err.message);
      }
    });

    await Promise.all(sendPromises);

    //console.log(`📡 FCM sending finished. Total sent: ${sent}, Failed: ${failed}`);
    return { success: true, sent, failed };

  } catch (err) {
    console.error("❌ Error sending notification to all students:", err);
    throw new Error("Cannot send notification to all students");
  }
}

async notifyEnrolledUsers(courseId, notificationData) {
  try {
    const enrollments = await Enrollment.find({ courseId}).select("userId").lean();

    for (const enrollment of enrollments) {
      //console.log(`Processing enrollment for user: ${enrollment.userId}`);
      const fcmToken = await FcmToken.findOne({ userId: enrollment.userId });
      console?.log(`Found FCM token for user: ${fcmToken}`);
      if (fcmToken) {
        await fcmService.sendPushNotification(fcmToken.token, notificationData);

        // Save notification
        await Notification.create({
          user_id: enrollment.userId,
          data: notificationData,
          status: 0,
        });
      }
    }
  } catch (error) {
    console.error("Error notifying enrolled users:", error);
  }
}
}

export default new NotificationService();
