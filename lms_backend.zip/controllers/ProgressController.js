import progressService from '../service/ProgressService.js';

// GET lesson progress
export const getLessonProgress = async (req, res) => {
  try {
    const { courseId, lessonId } = req.params;
    const userId = req.user.id;

    const progress = await progressService.getLessonProgress(userId, lessonId);

    res.status(200).json({ success: true, data: progress });
  } catch (error) {
    console.error(`Get lesson progress error: ${error.message}`);
    res.status(500).json({
      success: false,
      message: 'Failed to get lesson progress',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// PUT update progress
export const updateLessonProgress = async () => {
  try {
    const { courseId, lessonId } = req.params;
    const userId = req.user.id;
    const updateData = req.body;


    //console.log(`Updating progress for user ${userId}, lesson ${lessonId}`, updateData);

    const progress = await progressService.updateLessonProgress(userId, lessonId, updateData);

    res.status(200).json({
      success: true,
      message: 'Progress updated successfully',
      data: progress
    });
  } catch (error) {
    console.error(`Update lesson progress error: ${error.message}`);
    res.status(500).json({
      success: false,
      message: 'Failed to update lesson progress',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};


export const updateLessonProgressDirect = async (userId, lessonId, courseId, updateData) => {
  try {
    //console.log(`Direct update progress for user ${userId}, lesson ${lessonId}`, updateData);
    
    const progress = await progressService.updateLessonProgress(userId, lessonId, courseId, updateData);
    return progress;
  } catch (error) {
    console.error(`Direct update lesson progress error: ${error.message}`);
    throw error;
  }
};


// POST mark as complete
export const completeLessonProgress = async (req, res) => {
  try {
    const { courseId, lessonId } = req.params;
    const userId = req.user.id;
    const completionData = req.body;

    const progress = await progressService.completeLessonProgress(userId, lessonId, completionData);

    res.status(200).json({
      success: true,
      message: 'Lesson completed successfully',
      data: progress
    });
  } catch (error) {
    console.error(`Complete lesson error: ${error.message}`);
    res.status(500).json({
      success: false,
      message: 'Failed to complete lesson',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// GET course progress summary
export const getCourseProgress = async (req, res) => {
  try {
    const { courseId } = req.params;
    const userId = req.user.id;

    //console.log(`Fetching course progress for user ${userId}, course ${courseId}`);
    

    const progress = await progressService.getCourseProgress(userId, courseId);

    res.status(200).json({ success: true, data: progress });
  } catch (error) {
    console.error(`Get course progress error: ${error.message}`);
    res.status(500).json({
      success: false,
      message: 'Failed to get course progress',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// GET overall progress overview
export const getUserProgressOverview = async (req, res) => {
  try {
    const userId = req.user.id;
    const options = {
      page: parseInt(req.query.page) || 1,
      limit: parseInt(req.query.limit) || 20,
      courseId: req.query.courseId,
      completed: req.query.completed !== undefined ? req.query.completed === 'true' : undefined
    };

    const overview = await progressService.getUserProgressOverview(userId, options);

    res.status(200).json({ success: true, data: overview });
  } catch (error) {
    console.error(`Get user progress overview error: ${error.message}`);
    res.status(500).json({
      success: false,
      message: 'Failed to get progress overview',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// POST initialize lesson progress
export const initializeLessonProgress = async (req, res) => {
  try {
    const { courseId, lessonId } = req.params;
    const userId = req.user.id;
    const { sessionId, metadata } = req.body;

    const progress = await progressService.initializeLessonProgress(
      userId,
      courseId,
      lessonId,
      sessionId,
      metadata
    );

    res.status(201).json({
      success: true,
      message: 'Lesson progress initialized successfully',
      data: progress
    });
  } catch (error) {
    //console.log(`Initialize lesson progress error: ${error.message}`);
    res.status(500).json({
      success: false,
      message: 'Failed to initialize lesson progress',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// DELETE reset lesson progress
export const resetLessonProgress = async (req, res) => {
  try {
    const { courseId, lessonId } = req.params;
    const userId = req.user.id;

    const progress = await progressService.resetLessonProgress(userId, lessonId);

    res.status(200).json({
      success: true,
      message: 'Lesson progress reset successfully',
      data: progress
    });
  } catch (error) {
    console.error(`Reset lesson progress error: ${error.message}`);
    res.status(500).json({
      success: false,
      message: 'Failed to reset lesson progress',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};
