import certificateService from "../service/certificateService.js";
import { initRedis } from "../config/redisClient.js";
import courseProgressModel from "../models/Course.js";
import quizSubmissionModel from "../models/QuizSubmission.js";
import courseBundleModel from "../models/CourseBundle.js";
import User from "../models/user.js";
import CertificateTemplate from "../models/CertificateTemplate.js";
import puppeteer from "puppeteer";
import fs from "fs";
import path from "path";
import CourseEnrollment from "../models/CourseEnrollment.js";

export const createCertificate = async (req, res) => {
  try {

     let user_id;
     //console.log("Request user:", req.user);
    if (req.user && req.user.role == "admin") {
      user_id = req.body.user_id;
    } else {
      user_id = req.user?._id;
    }

    //console.log("Creating certificate for user:", user_id);

    const {
      course_id,
      quiz_id,
      bundle_id,
      type,
      status,
      serial_number,
      instructor_id,
      instructor_name,
      certification_template,
      remarks,
      grade,
      score,
      max_score,
      completion_date,
      total_duration,
      user_time_spent,
      final_grade,
      // causer_Id
    } = req.body;

    const certificate_url = req.files?.certificate_url?.[0]?.path.replace(
      /\\/g,
      "/"
    );
    const instructor_signature =
      req.files?.instructor_signature?.[0]?.path.replace(/\\/g, "/");

    // ✅ Validate completion based on type
    if (type === "course") {
      // const progress = await courseProgressModel.findOne({
      // user_id,
      // course_id,
      // });
      // if (!progress) {
      // return res.status(400).json({ success: false, message: "Course not completed by user" });
      // }
      //console.log(
        "Checking course completion for user:",
        user_id,
        "course:",
        course_id
      );

      // Check if user is enrolled in the course
      var course = await courseProgressModel.findOne({
        _id: course_id,
        enrolledStudents: { $in: [user_id] },
      });
      if (!course) {
        return res.status(400).json({
          success: false,
          message: "User is not enrolled in this course",
        });
      }
    }

    //console.log("Course found:", course);

    // Fetch instructor data
    const instructor = await User.findById(course.instructorId)
      .select("fullName")
      .lean();
    if (!instructor) {
      throw new Error("Instructor not found");
    }

    //console.log("Instructor found:", instructor.fullName);

    if (type === "quiz") {
      let quizSubmission = null;

      if (req.body.quiz_submission_id) {
        quizSubmission = await quizSubmissionModel.findById(
          req.body.quiz_submission_id
        );
      } else if (quiz_id && user_id) {
        quizSubmission = await quizSubmissionModel.findOne({
          user: user_id,
          quiz: quiz_id,
        });
      }

      if (!quizSubmission || !quizSubmission.passed) {
        return res
          .status(400)
          .json({ success: false, message: "Quiz not passed by user" });
      }

      // Use values from quiz submission
      req.body.quiz_submission_id = quizSubmission._id;
      req.body.score = quizSubmission.score;
      req.body.max_score = quizSubmission.totalMarks;
      req.body.quiz_id = quizSubmission.quiz;
    }

    if (type === "bundle") {
      const bundle = await courseBundleModel
        .findById(bundle_id)
        .populate("courses");
      if (!bundle) {
        return res
          .status(404)
          .json({ success: false, message: "Bundle not found" });
      }

      const completedCourses = await courseProgressModel.find({
        user_id,
        course_id: { $in: bundle.courses },
        completed: true,
      });

      if (completedCourses.length !== bundle.courses.length) {
        return res.status(400).json({
          success: false,
          message: "User has not completed all courses in the bundle",
        });
      }
    }

    var certificate = null;

    //check if certificate already exists for this user and course/quiz/bundle
    const existingCertificate =
      await certificateService.getCertificateByUserAndType(
        user_id,
        course_id,
        type,
        certification_template
      );

    if (!existingCertificate) {
      // ✅ Create certificate
      certificate = await certificateService.createCertificate({
        user_id,
        course_id: course_id || null,
        quiz_id: req.body.quiz_id || quiz_id || null,
        quiz_submission_id: req.body.quiz_submission_id || null,
        bundle_id: bundle_id || null,
        certification_template: certification_template || null,
        type,
        status,
        certificate_url,
        serial_number,
        instructor_id: course.instructorId || null,
        instructor_name: instructor.fullName || null,
        instructor_signature,
        remarks,
        grade,
        score: req.body.score || score,
        max_score: req.body.max_score || max_score,
        completion_date,
        total_duration,
        user_time_spent,
        final_grade,
      });

      // //console.log("Certificate created:", certificate);

      //console.log("Certificate created:", type, course);
      if (type == "course" && course_id) {
        //console.log("Updating CourseEnrollment for course:", course_id);
        await CourseEnrollment.findOneAndUpdate(
          { userId: user_id, courseId: course_id },
          { certificateIssued: true, certificateIssuedAt: new Date() }
        );
      } else if (type === "bundle" && bundle_id) {
        await CourseEnrollment.findOneAndUpdate(
          { userId: user_id, courseBundleId: bundle_id },
          { certificateIssued: true, certificateIssuedAt: new Date() }
        );
      }
    }

    certificate = existingCertificate || certificate;

    //generate certificate pdf base on template
    if (certificate.certification_template) {
      const template = await CertificateTemplate.findById(
        certificate.certification_template
      );
      if (!template) {
        return res
          .status(404)
          .json({ success: false, message: "Certificate template not found" });
      }

      // Render HTML with dynamic data
      const html = renderTemplate(template, template.elements, {
        ...certificate,
        student_name: certificate.user_id?.fullName || certificate.student_name,
        instructor_name: certificate.instructor_name,
        date: certificate.completion_date,
        platform_name: "Anshul",
        user_certificate_additional:
          certificate.user_certificate_additional || "",
        platform_signature: template.elements.platform_signature?.content || "",
        stamp: template.elements.stamp?.content || "",
        qr_code: certificate.qr_code || "",
      });
      const pdfBuffer = await htmlToPdfBuffer(html);
      // You can save pdfBuffer to file or upload to storage as needed
      //save in upload folder using upload-middelware 
      //path.join('uploads', files['image'][0].filename);

      const pdfFilePath = path.join('uploads', `certificate_${certificate._id}.pdf`);

      // const uploadDir = path.join(process.cwd(), "uploads", "certificates");
      // if (!fs.existsSync(uploadDir)) {
      //   fs.mkdirSync(uploadDir, { recursive: true });
      // }
      // const pdfFilePath = path.join(
      //   uploadDir,
      //   `certificate_${certificate._id}.pdf`
      // );
      fs.writeFileSync(pdfFilePath, pdfBuffer);
      // Update certificate with PDF URL
      certificate.certificate_url = pdfFilePath.replace(/\\/g, "/"); // Ensure forward
      //console.log("Certificate PDF saved at:", pdfFilePath);
      //slashes for URL compatibility
      await certificate.save();
      //console.log("Certificate PDF generated and saved at:", pdfFilePath);
    } else {
      //console.log("No template found for certificate, skipping PDF generation");
    }

    const redis = await initRedis();
    await redis.del("certificates:all*");

    res.status(201).json({
      success: true,
      message: "Certificate created successfully",
      data: certificate,
    });
  } catch (error) {
    console.error("Error creating certificate:", error);
    res.status(500).json({ success: false, message: error.message });
  }
};

export const getAllCertificates = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search = "",
      sortBy = "createdAt",
      sortOrder = "desc",
      type,
      user_id,
    } = req.query;

    const filters = {};
    if (type) filters.type = type;
    if (user_id) filters.user_id = user_id;

    const options = { page, limit, search, sortBy, sortOrder, filters };

    const redis = await initRedis();
    const cacheKey = `certificates:all:${JSON.stringify(options)}`;
    const cached = await redis.get(cacheKey);

    if (cached) {
      return res.status(200).json({
        success: true,
        message: "Certificates fetched from cache",
        data: JSON.parse(cached),
        fromCache: true,
      });
    }

    const data = await certificateService.getAllCertificates(options);
    await redis.setEx(cacheKey, 300, JSON.stringify(data));

    res.status(200).json({
      success: true,
      message: "Certificates fetched successfully",
      data,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const getCertificateById = async (req, res) => {
  try {
    const redis = await initRedis();
    // const cacheKey = `certificate:${req.params.id}`;
    // const cached = await redis.get(cacheKey);

    // if (cached) {
    //   return res.status(200).json({
    //     success: true,
    //     message: 'Certificate fetched from cache',
    //     data: JSON.parse(cached),
    //     fromCache: true
    //   });
    // }

    const certificate = await certificateService.getCertificateById(
      req.params.id
    );
    if (!certificate) {
      return res
        .status(404)
        .json({ success: false, message: "Certificate not found" });
    }

    // await redis.setEx(cacheKey, 300, JSON.stringify(certificate));
    res.status(200).json({
      success: true,
      message: "Certificate fetched successfully",
      data: certificate,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const updateCertificate = async (req, res) => {
  try {
    const updateData = { ...req.body };

    if (req.files?.certificateFile?.[0]) {
      updateData.certificate_url = req.files.certificateFile[0].path.replace(
        /\\/g,
        "/"
      );
    }

    if (req.files?.signatureFile?.[0]) {
      updateData.instructor_signature = req.files.signatureFile[0].path.replace(
        /\\/g,
        "/"
      );
    }

    const updated = await certificateService.updateCertificate(
      req.params.id,
      updateData
    );

    const redis = await initRedis();
    await redis.del("certificates:all*");
    await redis.del(`certificate:${req.params.id}`);

    res.status(200).json({
      success: true,
      message: "Certificate updated successfully",
      data: updated,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const deleteCertificate = async (req, res) => {
  try {
    const certificate = await certificateService.getCertificateById(
      req.params.id
    );

    if (!certificate) {
      return res
        .status(404)
        .json({ success: false, message: "Certificate not found" });
    }

    await certificateService.deleteCertificate(req.params.id);

    const redis = await initRedis();
    await redis.del("certificates:all*");
    await redis.del(`certificate:${req.params.id}`);

    res.status(200).json({
      success: true,
      message: "Certificate deleted successfully",
      data: certificate,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Helper to render template HTML with dynamic data - COMPLETELY BORDER-FREE
// Updated renderTemplate function with proper spacing
// FIXED: Helper to render template HTML with dynamic data
function renderTemplate(template, elements, data) {
  //console.log("Rendering template with data:", data);
  // //console.log('Template elements:', elements);

  // Build HTML for each enabled element
  let elementsHtml = "";
  if (elements) {
    Object.entries(elements).forEach(([key, el]) => {
      if (!el || !el.enable) return;
      const value = data[key] !== undefined ? data[key] : el.content || "";
      const style = `
        position: absolute;
        left: ${el.position_x || 0}px;
        top: ${el.position_y || 0}px;
        color: ${el.font_color || "#000"};
        font-size: ${el.font_size ? el.font_size + "px" : "16px"};
        font-weight: ${el.font_weight_bold ? "bold" : "normal"};
        text-align: ${
          el.text_center ? "center" : el.text_right ? "right" : "left"
        };
        ${el.styles || ""}
        width: auto;
        pointer-events: none;
        z-index: 10;
      `;

      // Render image elements
      if (el.image) {
        const imagePath = path.resolve(
          process.cwd(),
          el.image.replace(/\\/g, "/")
        );
        elementsHtml += `<img src="file://${imagePath}" style="${style} width:${
          el.image_size || 128
        }px; height:auto;" onerror="this.style.display='none'" />`;
      } else {
        elementsHtml += `<div style="${style}">${value}</div>`;
      }
    });
  }

  // FIXED: Properly handle background image with absolute path
  const backgroundImageUrl = template.image
    ? template.image.replace(/\\/g, "/")
    : `https://as1.ftcdn.net/v2/jpg/01/89/21/08/1000_F_189210864_ejz7Y1FbG05BdOom1WWaRbwGDXh1KIAo.jpg`;

  const signatureImage = template.elements?.platform_signature?.image
    ? template.elements.platform_signature.image.replace(/\\/g, "/")
    : "";

  const stampImage = template.elements?.stamp?.image
    ? template.elements.stamp.image.replace(/\\/g, "/")
    : "";

  //console.log("Background image URL:", backgroundImageUrl);
  //console.log("Elements HTML:", elements.title.content);

  const html = `
    <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Certificate of Completion</title>
    <style>
      /* Universal reset */
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      html,
      body {
        width: 100%;
        height: 100%;
        font-family: "Times New Roman", serif;
        display: flex;
        justify-content: center;
        align-items: center;
        background: #f0f0f0;
      }

      /* FIXED: Main certificate container with proper background handling */
      .certificate-container {
        position: relative;
        width: 297mm;
        height: 210mm;
        margin: 0;
        padding: 0;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        ${
          backgroundImageUrl
            ? `background-image: url('${backgroundImageUrl}');
           background-size: cover;
           background-position: center;
           background-repeat: no-repeat;`
            : "background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);"
        }
        overflow: hidden;
      }

      /* FIXED: Add overlay to ensure content visibility over background */
      .certificate-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: ${
          backgroundImageUrl ? "rgba(255, 255, 255, 0.1)" : "transparent"
        };
        z-index: 1;
      }

      /* Content area - properly positioned over background */
      .certificate-content {
        position: relative;
        z-index: 2;
        padding: 40px 60px;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
      }

      /* Title section */
      .certificate-title-box {
        padding: 10px 40px;
        position: relative;
      }

      .certificate-title {
        font-size:  ${elements.title.font_size || 36}px;
        font-weight: ${elements.title.font_weight_bold ? "bold" : "normal"};}
        color: ${elements.title.font_color || "#2c3e50"};
        line-height: 1.1;
        text-align: ${
          elements.title.text_center
            ? "center"
            : elements.title.text_right
            ? "right"
            : "left"
        };
        letter-spacing: 2px;
        margin-bottom: 10px;
        // top: ${elements.title.position_y || 0}px;
        // left: ${elements.title.position_x || 0}px;
        font-family: ${elements.title.styles || "Times New Roman"}, serif;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
      }

      .certificate-subtitle {
        font-size: 18px;
        color: #d4a574;
        font-style: italic;
        font-weight: 600;
        margin-bottom: 70px;
      }

      .certificate-text {
        font-size: 18px;
        color: #34495e;
        margin-bottom: 20px;
        line-height: 1.6;
      }

      .recipient-name {
        font-size: 36px;
        font-weight: bold;
        color: #2c3e50;
        margin: 10px 0 5px 0;
        text-decoration: underline;
        text-decoration-color: #d4a574;
        text-underline-offset: 8px;
        text-decoration-thickness: 3px;
        font-style: italic;
      }

      .completion-text {
        font-size: 18px;
        color: #34495e;
        margin-bottom: 60px;
        line-height: 1.6;
      }

      /* Footer section */
      .certificate-footer {
        position: absolute;
        bottom: 100px;
        left: 0;
        right: 0;
        z-index: 3;
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        padding: 0 100px;
        height: 80px;
      }

      .date-section {
        font-size: 16px;
        color: #7f8c8d;
        margin-top: 20px;
        margin-bottom: 10px;
        font-weight: 600;
      }

      .signature-section {
        text-align: center;
        margin-bottom: 10px;
        position: relative;
      }

      .signature-line {
        width: 200px;
        height: 2px;
        background: #d4a574;
        margin-bottom: 8px;
      }

      .signature-name {
        font-size: 16px;
        font-weight: bold;
        color: #2c3e50;
        margin-bottom: 2px;
      }

      .signature-title {
        font-size: 14px;
        color: #7f8c8d;
      }

      .verification-url {
        position: absolute;
        bottom: 8px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 12px;
        color: #95a5a6;
        z-index: 4;
      }

      /* Signature and stamp section styles */
      .signature-stamp-container {
        display: flex;
        gap: 40px;
        align-items: flex-end;
      }

      .signature-item {
        text-align: center;
      }

      .signature-image, .stamp-image {
        height: 60px;
        width: auto;
        display: block;
        margin-bottom: 8px;
      }

      .signature-label, .stamp-label {
        font-size: 14px;
        color: #7f8c8d;
      }

      /* FIXED: Custom dynamic elements with proper z-index */
      .dynamic-elements {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 5;
      }
      
      /* Print styles - A4 landscape enforcement */
      @media print {
        html,
        body {
          background: white;
          padding: 0;
          margin: 0;
          width: 100%;
          height: 100%;
        }

        .certificate-container {
          width: 297mm;
          height: 210mm;
          margin: 0;
          page-break-inside: avoid;
          box-shadow: none;
          ${
            backgroundImageUrl
              ? `background-image: url('${backgroundImageUrl}');
             background-size: cover;
             background-position: center;
             background-repeat: no-repeat;`
              : "background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);"
          }
        }
      }

      /* Page break styles - A4 landscape */
      @page {
        size: A4 landscape;
        margin: 0;
      }
    </style>
  </head>
  <body>
    <div class="certificate-container">
      <!-- FIXED: Add overlay for better content visibility -->
      <div class="certificate-overlay"></div>
      
      <!-- Dynamic elements from template 
      <div class="dynamic-elements">
        ${elementsHtml}
      </div>-->
      
      <!-- Main content -->
      <div class="certificate-content">
        <div class="certificate-title-box">
          <div class="certificate-title" style="color: ${
            elements.title.font_color || "#2c3e50"
          }; font-size: ${elements.title.font_size || 36}px; font-weight: ${
    elements.title.font_weight_bold ? "bold" : "normal"
  }; text-align: ${
    elements.title.text_center
      ? "center"
      : elements.title.text_right
      ? "right"
      : "left"
  };">
          ${elements.title.content}</div>
        </div>

        <div class="certificate-subtitle" style="color: ${
          elements.subtitle.font_color || "#2c3e50"
        }; font-size: ${elements.subtitle.font_size || 36}px; font-weight: ${
    elements.subtitle.font_weight_bold ? "bold" : "normal"
  }; text-align: ${
    elements.subtitle.text_center
      ? "center"
      : elements.subtitle.text_right
      ? "right"
      : "left"
  };"> ${elements.subtitle.content}</div>

        <div class="certificate-text" style="color: ${
          elements.body.font_color || "#2c3e50"
        }; font-size: ${elements.body.font_size || 36}px; font-weight: ${
    elements.body.font_weight_bold ? "bold" : "normal"
  }; text-align: ${
    elements.body.text_center
      ? "center"
      : elements.body.text_right
      ? "right"
      : "left"
  };">
          ${elements.body.content}
        </div>

        <div class="recipient-name" style="color: ${
          elements.student_name.font_color || "#2c3e50"
        }; font-size: ${
    elements.student_name.font_size || 36
  }px; font-weight: ${
    elements.student_name.font_weight_bold ? "bold" : "normal"
  }; text-align: ${
    elements.student_name.text_center
      ? "center"
      : elements.student_name.text_right
      ? "right"
      : "left"
  };">${data.student_name}</div>

        <div class="completion-text">
          <br />
          Your commitment to learning is truly commendable.
        </div>
        <div class="date-section" style="color: ${
          elements.date.font_color || "#2c3e50"
        }; font-size: ${elements.date.font_size || 36}px; font-weight: ${
    elements.date.font_weight_bold ? "bold" : "normal"
  }; text-align: ${
    elements.date.text_center
      ? "center"
      : elements.date.text_right
      ? "right"
      : "left"
  };">Date: ${
    data.completion_date
      ? new Date(data.completion_date).toLocaleDateString()
      : new Date().toLocaleDateString()
  }</div>

        <div class="certificate-footer">
          <div class="signature-section">
            <div class="signature-line"></div>
            <div class="signature-name" style="color: ${
              elements.instructor_name.font_color || "#2c3e50"
            }; font-size: ${
    elements.instructor_name.font_size || 36
  }px; font-weight: ${
    elements.instructor_name.font_weight_bold ? "bold" : "normal"
  }; text-align: ${
    elements.instructor_name.text_center
      ? "center"
      : elements.instructor_name.text_right
      ? "right"
      : "left"
  };">${data.instructor_name || elements.instructor_name.content}</div>
            <div class="signature-title">Course Instructor</div>
            <div class="signature-title">${
              elements.platform_name.content || "LMS"
            }</div> 
          </div>
          <div class="signature-stamp-container">
            <div class="signature-item">
                <img src="${signatureImage}" alt="Signature" class="signature-image" onerror="this.style.display='none'" />
                <div class="signature-label">Signature</div>
            </div>
            <div class="signature-item">
                <img src="${stampImage}" alt="Stamp" class="stamp-image" onerror="this.style.display='none'" />
                <div class="stamp-label">Stamp</div>
            </div>
          </div>
        </div>
        <div class="verification-url">${
          elements.hint.content || "Verify at: Nexprism LMS"
        }</div>
      </div>
    </div>
  </body>
</html>
  `;
  return html;
}

// FIXED: Generate PDF buffer from HTML using puppeteer
async function htmlToPdfBuffer(html) {
  let browser;
  try {
    browser = await puppeteer.launch({
      headless: "new",
      executablePath: "/usr/bin/google-chrome",
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-accelerated-2d-canvas",
        "--disable-gpu",
      ],
    }); 



    const page = await browser.newPage();
    await page.setViewport({ width: 1122, height: 794, deviceScaleFactor: 1 });

    await page.setContent(html, { waitUntil: "networkidle0" });

    await page.evaluate(() => {
      return new Promise((resolve) => {
        const images = Array.from(document.images);
        let loaded = 0;
        if (images.length === 0) return resolve();

        images.forEach((img) => {
          if (img.complete) {
            loaded++;
          } else {
            img.addEventListener("load", () => {
              loaded++;
              if (loaded === images.length) resolve();
            });
            img.addEventListener("error", () => {
              loaded++;
              if (loaded === images.length) resolve();
            });
          }
        });

        if (loaded === images.length) resolve();
        setTimeout(resolve, 3000);
      });
    });

    const buffer = await page.pdf({
      format: "A4",
      landscape: true,
      printBackground: true,
      margin: { top: 0, bottom: 0, left: 0, right: 0 },
    });

    return buffer;
  } catch (err) {
    console.error("Error generating PDF:", err?.message);
    throw new Error("Failed to generate PDF");
  } finally {
    if (browser) await browser.close();
  }
}
// Download certificate as PDF
export const downloadCertificatePdf = async (req, res, next) => {
  try {
    const { filePath, fileName } = await certificateService.downloadCertificatePdf(req.params.id);
    res.download(filePath, fileName, (err) => {
      if (err) {
        next(err);
      }
    });
  } catch (error) {
    next(error);
  }
};

// View certificate as PDF in browser
export const viewCertificatePdf = async (req, res) => {
  try {
    const certificate = await certificateService.getCertificateById(
      req.params.id
    );

    if (!certificate) {
      return res
        .status(404)
        .json({ success: false, message: "Certificate not found" });
    }
    const template = await CertificateTemplate.findById(
      certificate.certification_template || certificate.templateId
    );
    if (!template) {
      return res
        .status(404)
        .json({ success: false, message: "Certificate template not found" });
    }
    //console.log("Rendering template with data:", certificate.user_id?.fullName);

    const html = renderTemplate(template, template.elements, {
      ...certificate,
      student_name: certificate.user_id?.fullName || certificate.student_name,
      instructor_name: certificate.instructor_name,
      date: certificate.completion_date,
      platform_name: "Your Platform Name",
      user_certificate_additional:
        certificate.user_certificate_additional || "",
      platform_signature: template.elements.platform_signature?.content || "",
      stamp: template.elements.stamp?.content || "",
      qr_code: certificate.qr_code || "",
    });
    const pdfBuffer = await htmlToPdfBuffer(html);
    res.set({
      "Content-Type": "application/pdf",
      "Content-Disposition": "inline; filename=certificate.pdf",
    });
    res.send(pdfBuffer);
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
