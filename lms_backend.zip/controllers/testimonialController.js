import testimonialService from '../service/testimonialService.js';
import Testimonial from '../models/Testimonial.js';

// Admin: Add testimonial manually
export const addTestimonialAdmin = async (req, res) => {
  try {
    const { name, role, message, rating, courseId } = req.body;
    if (!message || !name) {
      return res.status(400).json({ success: false, message: 'Name and message are required.' });
    }
    const testimonial = await testimonialService.createTestimonial({ name, role, message, rating, courseId }, true);
    res.json({ success: true, message: 'Testimonial added and approved.', data: testimonial });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Admin: List all testimonials with filters
export const listTestimonialsAdmin = async (req, res) => {
  try {
    const { status, search, courseId } = req.query;
    let filter = {};
    if (status) filter.status = status;
    if (search) filter.message = { $regex: search, $options: 'i' };
    if (courseId) filter.courseId = courseId;
    const testimonials = await testimonialService.getTestimonials(filter, { sort: '-createdAt' });
    res.json({ success: true, message: 'Testimonials fetched.', data: testimonials });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Admin: Update testimonial
export const updateTestimonialAdmin = async (req, res) => {
  try {
    const { id } = req.params;
    const { message, status, rating } = req.body;
    const update = {};
    if (message) update.message = message;
    if (status) update.status = status;
    if (rating) update.rating = rating;
    const testimonial = await testimonialService.updateTestimonial(id, update);
    if (!testimonial) return res.status(404).json({ success: false, message: 'Testimonial not found.' });
    res.json({ success: true, message: 'Testimonial updated.', data: testimonial });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Admin: Delete testimonial
export const deleteTestimonialAdmin = async (req, res) => {
  try {
    const { id } = req.params;
    const testimonial = await testimonialService.deleteTestimonial(id);
    if (!testimonial) return res.status(404).json({ success: false, message: 'Testimonial not found.' });
    res.json({ success: true, message: 'Testimonial deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// User: Submit own testimonial
export const submitTestimonial = async (req, res) => {
  try {
    const { message, rating, role, courseId } = req.body;
    if (!message) {
      return res.status(400).json({ success: false, message: 'Message is required.' });
    }
    const userId = req.user?._id; // Assume req.user is set by auth middleware
    const testimonial = await testimonialService.createTestimonial({ userId, message, rating, role, courseId }, false);
    res.json({ success: true, message: 'Testimonial submitted for approval.', data: testimonial });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// User: Get all approved testimonials
export const getApprovedTestimonials = async (req, res) => {
  try {
    const { courseId } = req.query;
    const filter = { status: 'approved' };
    
    // Add courseId filter if provided
    if (courseId) {
      filter.courseId = courseId;
    }
    
    const testimonials = await testimonialService.getTestimonials(filter, { sort: '-createdAt' });
    res.json({ success: true, message: 'Approved testimonials fetched.', data: testimonials });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// User: Get single testimonial (if approved or belongs to user)
export const getTestimonial = async (req, res) => {
  try {
    const { id } = req.params;
    const testimonial = await testimonialService.getTestimonialById(id);
    if (!testimonial) return res.status(404).json({ success: false, message: 'Testimonial not found.' });
    if (testimonial.status === 'approved' || (req.user && testimonial.userId?.toString() === req.user._id.toString())) {
      return res.json({ success: true, message: 'Testimonial fetched.', data: testimonial });
    }
    res.status(403).json({ success: false, message: 'Not authorized to view this testimonial.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};