import ChatRoom from '../models/ChatRoom.js';
import Message from '../models/Message.js';
import mongoose from 'mongoose';
import GroupChatRoom from '../models/GroupChatRoom.js';
import GroupMessage from '../models/GroupMessage.js';
import User from '../models/user.js'; // Import User model

export const createOrGetChatRoom = async (req, res) => {
  try {
    // Check if req.user is set
    if (!req.user || !req.user._id) {
      console.error('createOrGetChatRoom: req.user is undefined or missing _id', {
        user: req.user,
        headers: req.headers,
        body: req.body
      });
      return res.status(401).json({ message: 'Authentication failed: User not authenticated' });
    }

    const { receiverId } = req.body;
    const senderId = req.user._id;

    //console.log('createOrGetChatRoom: Starting', { senderId, receiverId });

    if (!receiverId) {
      return res.status(400).json({ message: 'Receiver ID required' });
    }

    if (!mongoose.Types.ObjectId.isValid(receiverId)) {
      return res.status(400).json({ message: 'Invalid receiver ID' });
    }

    // Validate sender and receiver exist in User collection
    const sender = await User.findById(senderId);
    const receiver = await User.findById(receiverId);
    if (!sender) {
      return res.status(400).json({ message: 'Sender user does not exist' });
    }
    if (!receiver) {
      return res.status(400).json({ message: 'Receiver user does not exist' });
    }

    // Check if room exists
    let room = await ChatRoom.findOne({
      participants: { $all: [senderId, receiverId], $size: 2 }
    });

    if (!room) {
      room = await ChatRoom.create({
        participants: [senderId, receiverId]
      });
      //console.log('createOrGetChatRoom: New room created', { roomId: room._id });
    } else {
      //console.log('createOrGetChatRoom: Existing room found', { roomId: room._id });
    }

    return res.status(200).json({
      message: 'Chat room retrieved/created successfully',
      roomId: room._id,
      participants: room.participants
    });
  } catch (err) {
    console.error('Create/Get Chat Room Error:', err);
    return res.status(500).json({ message: 'Failed to create/get chat room', error: err.message });
  }
};

export const getAllChatRooms = async (req, res) => {
  try {
    if (!req.user || !req.user._id) {
      console.error('getAllChatRooms: req.user is undefined or missing _id', {
        user: req.user,
        headers: req.headers
      });
      return res.status(401).json({ message: 'Authentication failed: User not authenticated' });
    }

    const userId = req.user._id;

    // Fetch all chat rooms for the user
    const rooms = await ChatRoom.find({ participants: userId })
      .populate('participants', 'fullName email')
      .lean();

    // Added: Calculate unread message count for each room
    const roomsWithUnreadCount = await Promise.all(
      rooms.map(async (room) => {
        const unreadCount = await Message.countDocuments({
          chatRoomId: room._id,
          receiver: userId,
          isRead: false
        });
        return { ...room, unreadCount };
      })
    );

    return res.status(200).json({
      message: 'Chat rooms retrieved successfully',
      // Modified: Return rooms with unread count
      rooms: roomsWithUnreadCount
    });
  } catch (err) {
    console.error('Get All Chat Rooms Error:', err);
    return res.status(500).json({ message: 'Failed to retrieve chat rooms', error: err.message });
  }
};

export const getMessages = async (req, res) => {
  try {
    if (!req.user || !req.user._id) {
      console.error('getMessages: req.user is undefined or missing _id', {
        user: req.user,
        headers: req.headers
      });
      return res.status(401).json({ message: 'Authentication failed: User not authenticated' });
    }

    const { roomId } = req.params;
    const { limit = 20, skip = 0 } = req.query;
    const userId = req.user._id;

    if (!mongoose.Types.ObjectId.isValid(roomId)) {
      return res.status(400).json({ message: 'Invalid room ID' });
    }

    const room = await ChatRoom.findOne({ _id: roomId, participants: userId });
    if (!room) {
      return res.status(403).json({ message: 'Not authorized to view this chat room' });
    }

    // Fetch messages with pagination
    const messages = await Message.find({ chatRoomId: roomId })
      .sort({ createdAt: -1 })
      .skip(parseInt(skip))
      .limit(parseInt(limit))
      .populate('sender receiver', 'fullName')
      .lean();

    // Added: Count unread messages for the authenticated user in this room
    const unreadCount = await Message.countDocuments({
      chatRoomId: roomId,
      receiver: userId,
      isRead: false
    });

    return res.status(200).json({
      message: 'Messages retrieved successfully',
      messages,
      // Added: Include unread message count in the response
      unreadCount
    });
  } catch (err) {
    console.error('Get Messages Error:', err);
    return res.status(500).json({ message: 'Failed to retrieve messages', error: err.message });
  }
};

export const sendMessage = async (req, res) => {
  try {
    if (!req.user || !req.user._id) {
      console.error('sendMessage: req.user is undefined or missing _id', {
        user: req.user,
        headers: req.headers,
        body: req.body
      });
      return res.status(401).json({ message: 'Authentication failed: User not authenticated' });
    }

    const { roomId, receiverId, message } = req.body;
    const senderId = req.user._id;

    if (!roomId || !receiverId || !message) {
      return res.status(400).json({ message: 'Missing required fields: roomId, receiverId, message' });
    }

    if (!mongoose.Types.ObjectId.isValid(roomId) || !mongoose.Types.ObjectId.isValid(receiverId)) {
      return res.status(400).json({ message: 'Invalid room ID or receiver ID' });
    }

    // Validate receiver exists
    const receiver = await User.findById(receiverId);
    if (!receiver) {
      return res.status(400).json({ message: 'Receiver user does not exist' });
    }

    const room = await ChatRoom.findOne({ _id: roomId, participants: { $all: [senderId, receiverId], $size: 2 } });
    if (!room) {
      return res.status(403).json({ message: 'Not authorized to send message in this chat room' });
    }

    const newMessage = await Message.create({
      chatRoomId: roomId,
      sender: senderId,
      receiver: receiverId,
      message
    });

    return res.status(201).json({
      message: 'Message sent successfully',
      newMessage
    });
  } catch (err) {
    console.error('Send Message Error:', err);
    return res.status(500).json({ message: 'Failed to send message', error: err.message });
  }
};

export const markMessagesAsRead = async (req, res) => {
  try {
    if (!req.user || !req.user._id) {
      console.error('markMessagesAsRead: req.user is undefined or missing _id', {
        user: req.user,
        headers: req.headers,
        body: req.body
      });
      return res.status(401).json({ message: 'Authentication failed: User not authenticated' });
    }

    const { roomId, senderId } = req.body;
    const receiverId = req.user._id;

    if (!roomId || !senderId) {
      return res.status(400).json({ message: 'Missing required fields: roomId, senderId' });
    }

    if (!mongoose.Types.ObjectId.isValid(roomId) || !mongoose.Types.ObjectId.isValid(senderId)) {
      return res.status(400).json({ message: 'Invalid room ID or sender ID' });
    }

    // Validate sender exists
    const sender = await User.findById(senderId);
    if (!sender) {
      return res.status(400).json({ message: 'Sender user does not exist' });
    }

    const room = await ChatRoom.findOne({ _id: new mongoose.Types.ObjectId(roomId), participants: new mongoose.Types.ObjectId(receiverId) });
    if (!room) {
      return res.status(403).json({ message: 'Not authorized to mark messages in this chat room' });
    }

    //console.log('markMessagesAsRead: Marking messages as read', { roomId, senderId, receiverId });

    const updateResult = await Message.updateMany(
      {
        chatRoomId: new mongoose.Types.ObjectId(roomId),
        sender: new mongoose.Types.ObjectId(senderId),
        receiver: new mongoose.Types.ObjectId(receiverId),
        isRead: false
      },
      { $set: { isRead: true } }
    );

    //console.log('markMessagesAsRead: Update result', {
      matchedCount: updateResult.matchedCount,
      modifiedCount: updateResult.modifiedCount
    });

    if (updateResult.matchedCount === 0) {
      return res.status(200).json({
        message: 'No unread messages found to mark as read'
      });
    }

    return res.status(200).json({
      message: 'Messages marked as read successfully',
      modifiedCount: updateResult.modifiedCount
    });
  } catch (err) {
    console.error('Mark Messages As Read Error:', err);
    return res.status(500).json({ message: 'Failed to mark messages as read', error: err.message });
  }
};


export const createOrGetGroupChatRoom = async (req, res) => {
  try {
    if (!req.user || !req.user._id) {
      console.error('createOrGetGroupChatRoom: req.user is undefined or missing _id', {
        user: req.user,
        headers: req.headers,
        body: req.body
      });
      return res.status(401).json({ message: 'Authentication failed: User not authenticated' });
    }

    const { participants } = req.body; // Array of participant IDs (excluding sender)
    const senderId = req.user._id;

    //console.log('createOrGetGroupChatRoom: Starting', { senderId, participants });

    if (!Array.isArray(participants) || participants.length < 2) {
      return res.status(400).json({ message: 'Participants array required with at least 2 IDs for group chat' });
    }

    const allIds = [senderId, ...participants];
    for (const id of allIds) {
      if (!mongoose.Types.ObjectId.isValid(id)) {
        return res.status(400).json({ message: `Invalid ID: ${id}` });
      }
    }

    const users = await User.find({ _id: { $in: allIds } });

    //console.log('createOrGetGroupChatRoom: Fetched users', { fetchedCount: users.length, expectedCount: allIds.length });
    if (users.length !== allIds.length) {
      return res.status(400).json({ message: 'One or more users do not exist' });
    }

    let allParticipants = allIds.map(id => new mongoose.Types.ObjectId(id));
    allParticipants.sort((a, b) => a.toString().localeCompare(b.toString()));

    let groupRoom = await GroupChatRoom.findOne({
      participants: { $all: allParticipants, $size: allParticipants.length }
    });

    if (!groupRoom) {
      groupRoom = await GroupChatRoom.create({
        participants: allParticipants
      });
      //console.log('createOrGetGroupChatRoom: New group room created', { groupRoomId: groupRoom._id });
    } else {
      //console.log('createOrGetGroupChatRoom: Existing group room found', { groupRoomId: groupRoom._id });
    }

    return res.status(200).json({
      message: 'Group chat room retrieved/created successfully',
      groupRoomId: groupRoom._id,
      participants: groupRoom.participants
    });
  } catch (err) {
    console.error('Create/Get Group Chat Room Error:', err);
    return res.status(500).json({ message: 'Failed to create/get group chat room', error: err.message });
  }
};

export const getAllGroupChatRooms = async (req, res) => {
  try {
    if (!req.user || !req.user._id) {
      console.error('getAllGroupChatRooms: req.user is undefined or missing _id', {
        user: req.user,
        headers: req.headers
      });
      return res.status(401).json({ message: 'Authentication failed: User not authenticated' });
    }

    const userId = req.user._id;

    const groupRooms = await GroupChatRoom.find({ participants: userId })
      .populate('participants', 'fullName email')
      .lean();

    const groupRoomsWithUnreadCount = await Promise.all(
      groupRooms.map(async (groupRoom) => {
        const unreadCount = await GroupMessage.countDocuments({
          groupChatRoomId: groupRoom._id,
          readBy: { $ne: userId }
        });
        return { ...groupRoom, unreadCount };
      })
    );

    return res.status(200).json({
      message: 'Group chat rooms retrieved successfully',
      groupRooms: groupRoomsWithUnreadCount
    });
  } catch (err) {
    console.error('Get All Group Chat Rooms Error:', err);
    return res.status(500).json({ message: 'Failed to retrieve group chat rooms', error: err.message });
  }
};

export const getGroupMessages = async (req, res) => {
  try {
    if (!req.user || !req.user._id) {
      console.error('getGroupMessages: req.user is undefined or missing _id', {
        user: req.user,
        headers: req.headers
      });
      return res.status(401).json({ message: 'Authentication failed: User not authenticated' });
    }

    const { groupRoomId } = req.params;
    const { limit = 20, skip = 0 } = req.query;
    const userId = req.user._id;

    if (!mongoose.Types.ObjectId.isValid(groupRoomId)) {
      return res.status(400).json({ message: 'Invalid group room ID' });
    }

    const groupRoom = await GroupChatRoom.findOne({ _id: groupRoomId, participants: userId });
    if (!groupRoom) {
      return res.status(403).json({ message: 'Not authorized to view this group chat room' });
    }

    const groupMessages = await GroupMessage.find({ groupChatRoomId: groupRoomId })
      .sort({ createdAt: -1 })
      .skip(parseInt(skip))
      .limit(parseInt(limit))
      .populate('sender', 'fullName')
      .lean();

    const unreadCount = await GroupMessage.countDocuments({
      groupChatRoomId: groupRoomId,
      readBy: { $ne: userId }
    });

    return res.status(200).json({
      message: 'Group messages retrieved successfully',
      groupMessages,
      unreadCount
    });
  } catch (err) {
    console.error('Get Group Messages Error:', err);
    return res.status(500).json({ message: 'Failed to retrieve group messages', error: err.message });
  }
};

export const sendGroupMessage = async (req, res) => {
  try {
    if (!req.user || !req.user._id) {
      console.error('sendGroupMessage: req.user is undefined or missing _id', {
        user: req.user,
        headers: req.headers,
        body: req.body
      });
      return res.status(401).json({ message: 'Authentication failed: User not authenticated' });
    }

    const { groupRoomId, message } = req.body;
    const senderId = req.user._id;

    if (!groupRoomId || !message) {
      return res.status(400).json({ message: 'Missing required fields: groupRoomId, message' });
    }

    if (!mongoose.Types.ObjectId.isValid(groupRoomId)) {
      return res.status(400).json({ message: 'Invalid group room ID' });
    }

    const groupRoom = await GroupChatRoom.findOne({ _id: groupRoomId, participants: senderId });
    if (!groupRoom) {
      return res.status(403).json({ message: 'Not authorized to send message in this group chat room' });
    }

    const newGroupMessage = await GroupMessage.create({
      groupChatRoomId: groupRoomId,
      sender: senderId,
      message,
      readBy: [senderId]
    });

    return res.status(201).json({
      message: 'Group message sent successfully',
      newGroupMessage
    });
  } catch (err) {
    console.error('Send Group Message Error:', err);
    return res.status(500).json({ message: 'Failed to send group message', error: err.message });
  }
};

export const markGroupMessagesAsRead = async (req, res) => {
  try {
    if (!req.user || !req.user._id) {
      console.error('markGroupMessagesAsRead: req.user is undefined or missing _id', {
        user: req.user,
        headers: req.headers,
        body: req.body
      });
      return res.status(401).json({ message: 'Authentication failed: User not authenticated' });
    }

    const { groupRoomId } = req.body;
    const userId = req.user._id;

    if (!groupRoomId) {
      return res.status(400).json({ message: 'Missing required field: groupRoomId' });
    }

    if (!mongoose.Types.ObjectId.isValid(groupRoomId)) {
      return res.status(400).json({ message: 'Invalid group room ID' });
    }

    const groupRoom = await GroupChatRoom.findOne({ _id: new mongoose.Types.ObjectId(groupRoomId), participants: new mongoose.Types.ObjectId(userId) });
    if (!groupRoom) {
      return res.status(403).json({ message: 'Not authorized to mark messages in this group chat room' });
    }

    //console.log('markGroupMessagesAsRead: Marking group messages as read', { groupRoomId, userId });

    const updateResult = await GroupMessage.updateMany(
      {
        groupChatRoomId: new mongoose.Types.ObjectId(groupRoomId),
        readBy: { $ne: new mongoose.Types.ObjectId(userId) }
      },
      { $addToSet: { readBy: new mongoose.Types.ObjectId(userId) } }
    );

    //console.log('markGroupMessagesAsRead: Update result', {
      matchedCount: updateResult.matchedCount,
      modifiedCount: updateResult.modifiedCount
    });

    if (updateResult.matchedCount === 0) {
      return res.status(200).json({
        message: 'No unread group messages found to mark as read'
      });
    }

    return res.status(200).json({
      message: 'Group messages marked as read successfully',
      modifiedCount: updateResult.modifiedCount
    });
  } catch (err) {
    console.error('Mark Group Messages As Read Error:', err);
    return res.status(500).json({ message: 'Failed to mark group messages as read', error: err.message });
  }
};