import enrollmentService from '../service/enrollmentService.js';
import Course from '../models/Course.js';
import { initRedis } from '../config/redisClient.js';
import fcmTokenss from "../models/fcmTokens.js";
import notificationService from "../utils/notificationService.js";
import Notification from "../models/Notifications.js";

export const createEnrollment = async (req, res) => {
  try {
    // If plan, set type
    if (req.body.coursePlanId) {
      req.body.type = 'coursePlan';
    }
    const enrollment = await enrollmentService.createEnrollment(req.body, res);

    const redis = await initRedis();
    await redis.del('enrollments:all*');

    res.status(201).json({
      success: true,
      message: 'Enrollment created successfully',
      data: enrollment,
    });
  } catch (error) {
    console.error('createEnrollment Error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
};

// notification without 
export const createFreeEnrollment = async (req, res) => {
  try {
    const enrollment = await enrollmentService.createFreeEnrollment(req.body, req, res);

    const redis = await initRedis();
    await redis.del('enrollments:all*');

    res.status(201).json({
      success: true,
      message: 'Free enrollment created successfully',
      data: enrollment,
    });
  } catch (error) {
    console.error('createFreeEnrollment Error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
};




export const getAllEnrollments = async (req, res) => {
  try {
    const { userId, courseId, courseBundel } = req.query;
    const options = { userId, courseId, courseBundel };

    const redis = await initRedis();
    const cacheKey = `enrollments:all:${JSON.stringify(options)}`;
    const cached = await redis.get(cacheKey);

    if (cached) {
      return res.status(200).json({
        success: true,
        message: 'Enrollments fetched from cache',
        data: JSON.parse(cached),
        fromCache: true,
      });
    }

    const enrollments = await enrollmentService.getAllEnrollments(options);
    await redis.setEx(cacheKey, 300, JSON.stringify(enrollments));

    res.status(200).json({
      success: true,
      message: 'Enrollments fetched successfully',
      data: enrollments,
    });
  } catch (error) {
    console.error('getAllEnrollments Error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
};

export const getEnrollmentById = async (req, res) => {
  try {
    const enrollment = await enrollmentService.getEnrollmentById(req.params.id);
    if (!enrollment)
      return res.status(404).json({ success: false, message: 'Enrollment not found' });

    res.status(200).json({
      success: true,
      message: 'Enrollment fetched successfully',
      data: enrollment,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const deleteEnrollment = async (req, res) => {
  try {
    await enrollmentService.deleteEnrollment(req.params.id);

    const redis = await initRedis();
    await redis.del('enrollments:all*');

    res.status(200).json({ success: true, message: 'Enrollment deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const updateEnrollment = async (req, res) => {
  try {
    const updated = await enrollmentService.updateEnrollment(req.params.id, req.body);
    if (!updated) return res.status(404).json({ success: false, message: 'Enrollment not found' });

    const redis = await initRedis();
    await redis.del(`enrollment:${req.params.id}`);
    await redis.del('enrollments:all*');

    res.status(200).json({ success: true, message: 'Enrollment updated successfully', data: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const adminEnrollStudent = async (req, res) => {
  try {
    const { userId, courseId, courseBundleId, accessExpiry, customPrice, addToRevenue } = req.body;

    if (!userId) {
      return res.status(400).json({ success: false, message: 'userId is required' });
    }

    const hasCourse = !!courseId;
    const hasBundle = !!courseBundleId;

    if (hasCourse && hasBundle) {
      return res.status(400).json({ success: false, message: 'Provide either courseId or courseBundleId, not both' });
    }

    if (!hasCourse && !hasBundle) {
      return res.status(400).json({ success: false, message: 'Either courseId or courseBundleId must be provided' });
    }

    const type = hasCourse ? 'course' : 'courseBundle';

    // 1. Create enrollment with custom accessExpiry and customPrice
    const enrollmentData = {
      userId,
      courseId,
      courseBundleId,
      type,
      enrollmentSource: 'admin',
      accessExpiry: accessExpiry ? new Date(accessExpiry) : undefined,
      customPrice: customPrice !== undefined ? Number(customPrice) : undefined,
      addToRevenue: addToRevenue === true || addToRevenue === 'true' ? true : false,
    };

    const enrollment = await enrollmentService.createEnrollment(enrollmentData, res);

    // 2. If courseId provided, update Course.enrolledStudents and optionally revenue/salesCount
    if (hasCourse) {
      await Course.findByIdAndUpdate(
        courseId,
        {
          $addToSet: { enrolledStudents: userId }, // avoids duplicates
          $inc: { enrolledStudentsCount: 1 }
        }
      );
      // Optionally add to revenue/salesCount
      if (addToRevenue && customPrice !== undefined) {
        await Course.findByIdAndUpdate(
          courseId,
          { $inc: { salesCount: 1, revenue: Number(customPrice) } }
        );
      }
    }

    const redis = await initRedis();
    await redis.del('enrollments:all*');

    return res.status(201).json({
      success: true,
      message: 'Student enrolled successfully by admin',
      data: enrollment,
    });
  } catch (error) {
    console.error('adminEnrollStudent Error:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// New API: Remove enrollment and update course enrolledStudents/enrolledStudentsCount
export const removeEnrollmentAndUpdateCourse = async (req, res) => {
  try {
    const enrollmentId = req.params.id;
    const enrollment = await enrollmentService.getEnrollmentById(enrollmentId);
    if (!enrollment) {
      return res.status(404).json({ success: false, message: 'Enrollment not found' });
    }

    // Remove enrollment
    await enrollmentService.deleteEnrollment(enrollmentId);

    // If course enrollment, update course
    if (enrollment.courseId && enrollment.userId) {
      await Course.findByIdAndUpdate(
        enrollment.courseId._id || enrollment.courseId,
        {
          $pull: { enrolledStudents: enrollment.userId._id || enrollment.userId },
          $inc: { enrolledStudentsCount: -1 }
        }
      );
    }

    // Optionally, handle courseBundle similarly if needed

    const redis = await initRedis();
    await redis.del('enrollments:all*');

    return res.status(200).json({
      success: true,
      message: 'Enrollment deleted and course updated successfully'
    });
  } catch (error) {
    console.error('removeEnrollmentAndUpdateCourse Error:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

