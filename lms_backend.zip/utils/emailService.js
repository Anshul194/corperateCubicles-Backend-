import nodemailer from "nodemailer";
import dotenv from "dotenv";
dotenv.config();

/**
 * EmailService handles sending different types of emails from different sender addresses.
 * 
 * Transactional: noreply@edrilla.com (process.env.TransactionalEmail / process.env.TransactionalEmailPass)
 * Founder/Casual: sahil@edrilla.com (process.env.FounderEmail / process.env.FounderEmailPass)
 * Support: support@edrilla.com (process.env.SupportEmail / process.env.SupportEmailPass)
 */
class EmailService {
  constructor() {
    // Log environment variables for debugging (avoid logging passwords in production)
    //console.log("SMTP Configuration:", {
      host: process.env.SMTP_HOST,
      port: process.env.SMTP_PORT,
      secure: process.env.SMTP_SECURE,
      TransactionalEmail: process.env.TransactionalEmail,
      FounderEmail: process.env.FounderEmail,
      SupportEmail: process.env.SupportEmail,
    });

    // Prepare transporters for each sender
    this.transporters = {
      transactional: nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT),
        secure: process.env.SMTP_SECURE === "true",
        auth: {
          user: process.env.TransactionalEmail,
          pass: process.env.TransactionalEmailPass,
        },
        tls: {
          rejectUnauthorized: false,
        },
      }),
      founder: nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT),
        secure: process.env.SMTP_SECURE === "true",
        auth: {
          user: process.env.FounderEmail,
          pass: process.env.FounderEmailPass,
        },
        tls: {
          rejectUnauthorized: false,
        },
      }),
      support: nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT),
        secure: process.env.SMTP_SECURE === "true",
        auth: {
          user: process.env.SupportEmail,
          pass: process.env.SupportEmailPass,
        },
        tls: {
          rejectUnauthorized: false,
        },
      }),
    };
  }

  /**
   * Helper to get the correct "from" field for each type of email.
   */
  getFrom(type = "transactional") {
    switch (type) {
      case "transactional":
        return `"Edrilla" <${process.env.TransactionalEmail || "noreply@edrilla.com"}>`;
      case "founder":
        return `"Sahil (Edrilla)" <${process.env.FounderEmail || "sahil@edrilla.com"}>`;
      case "support":
        return `"Edrilla Support" <${process.env.SupportEmail || "support@edrilla.com"}>`;
      default:
        return `"Edrilla" <${process.env.TransactionalEmail || "noreply@edrilla.com"}>`;
    }
  }

  /**
   * Helper to get the correct transporter for each type of email.
   */
  getTransporter(type = "transactional") {
    if (type === "transactional") return this.transporters.transactional;
    if (type === "founder") return this.transporters.founder;
    if (type === "support") return this.transporters.support;
    return this.transporters.transactional;
  }

  /**
   * Send OTP/verification email (Transactional)
   */
  async sendOtpEmail(email, otp, userName = 'User') {
    const mailOptions = {
      from: this.getFrom("transactional"),
      to: email,
      subject: 'Your OTP for Verification',
      html: `
        <div style="font-family: Arial, sans-serif; line-height: 1.5;">
          <h2>OTP Verification</h2>
          <p>Hello <strong>${userName}</strong>,</p>
          <p>Your One-Time Password (OTP) for verification is:</p>
          <h3 style="color: #007bff;">${otp}</h3>
          <p>This OTP is valid for 10 minutes. Please use it to complete your verification.</p>
          <p>If you didn’t request this OTP, please ignore this email or contact our support team.</p>
          <hr />
          <p style="font-size: 12px; color: #777;">This is an automated email, please do not reply.</p>
        </div>
      `,
    };

    try {
      const info = await this.getTransporter("transactional").sendMail(mailOptions);
      //console.log('✅ OTP email sent:', info.messageId);
      return { success: true, messageId: info.messageId };
    } catch (error) {
      console.error('❌ Error sending OTP email:', error);
      throw new Error(`Failed to send OTP email: ${error.message}`);
    }
  }

  /**
   * Send password reset email (Transactional)
   */
  async sendPasswordResetEmail(email, resetToken, userName) {
    const resetUrl = `${process.env.FRONTEND_URL || "https://edrilla.com"
      }/reset-password?token=${resetToken}`;

    const mailOptions = {
      from: this.getFrom("transactional"),
      to: email,
      subject: "Password Reset Request",
      html: `
       <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset - Edrilla</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f4; font-family: Arial, sans-serif;">
    <table role="presentation" style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="padding: 20px 0;">
                <table role="presentation" style="width: 100%; max-width: 600px; margin: 0 auto; background-color: #191a17; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
                    
                    <!-- Header with Logo -->
                    <tr>
                        <td style="background-color: #93bb3d; padding: 30px 40px; text-align: center;">
                            <img src="https://edrilla.com/logo.svg" alt="Edrilla Logo" style="height: 40px; width: auto; display: block; margin: 0 auto 15px auto;">
                            <h1 style="color: #191a17; margin: 0; font-size: 24px; font-weight: bold;">Password Reset Request</h1>
                        </td>
                    </tr>
                    
                    <!-- Main Content -->
                    <tr>
                        <td style="padding: 40px; color: #ffffff;">
                            <p style="margin: 0 0 20px 0; font-size: 16px; line-height: 1.5;">
                                Hello <strong style="color: #93bb3d;">${userName}</strong>,
                            </p>
                            
                            <p style="margin: 0 0 25px 0; font-size: 16px; line-height: 1.5;">
                                We received a request to reset your password for your Edrilla account. If you made this request, click the button below to create a new password.
                            </p>
                            
                            <!-- Reset Button -->
                            <table role="presentation" style="margin: 30px 0;">
                                <tr>
                                    <td style="text-align: center;">
                                        <a href="${resetUrl}" style="display: inline-block; padding: 15px 30px; background-color: #93bb3d; color: #191a17; text-decoration: none; border-radius: 25px; font-weight: bold; font-size: 16px; text-align: center; transition: background-color 0.3s ease;">
                                            Reset My Password
                                        </a>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- Alternative Link -->
                            <div style="background-color: #2a2b28; padding: 20px; border-radius: 8px; margin: 25px 0;">
                                <p style="margin: 0 0 10px 0; font-size: 14px; color: #cccccc;">
                                    If the button doesn't work, copy and paste this link into your browser:
                                </p>
                                <p style="margin: 0; word-break: break-all; font-size: 14px;">
                                    <a href="${resetUrl}" style="color: #93bb3d; text-decoration: underline;">${resetUrl}</a>
                                </p>
                            </div>
                            
                            <!-- Security Notice -->
                            <div style="border-left: 4px solid #93bb3d; padding-left: 20px; margin: 25px 0;">
                                <p style="margin: 0 0 10px 0; font-size: 14px; color: #ff9999; font-weight: bold;">
                                    ⏰ Important Security Notice
                                </p>
                                <p style="margin: 0; font-size: 14px; line-height: 1.4; color: #cccccc;">
                                    This reset link will expire in <strong>1 hour</strong> for your security.
                                </p>
                            </div>
                            
                            <p style="margin: 25px 0 0 0; font-size: 16px; line-height: 1.5;">
                                If you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #0f100e; padding: 30px 40px; text-align: center; border-top: 2px solid #93bb3d;">
                            <p style="margin: 0 0 15px 0; color: #93bb3d; font-size: 18px; font-weight: bold;">
                                Edrilla
                            </p>
                            <p style="margin: 0; font-size: 12px; color: #888888; line-height: 1.4;">
                                This is an automated email, please do not reply.<br>
                                If you need help, contact our support team.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
      `,
    };

    try {
      const info = await this.getTransporter("transactional").sendMail(mailOptions);
      //console.log("✅ Password reset email sent:", info.messageId);
      return { success: true, messageId: info.messageId };
    } catch (error) {
      console.error("❌ Error sending email:", error);
      throw new Error(`Failed to send reset email: ${error.message}`);
    }
  }

  /**
   * Send order confirmation email (Transactional)
   */
  async sendOrderConfirmationEmail(email, name, password) {
    console?.log("Sending order confirmation email to:", email);
    const mailOptions = {
      from: this.getFrom("transactional"),
      to: email,
      subject: "Course Enrollment Confirmation",
      html: `
      <div style="font-family: Arial, sans-serif; line-height: 1.5;">
        <h2>Course Enrollment Confirmation</h2>
        <p>Hello <strong>${name}</strong>,</p>
        <p>Thank you for enrolling in our course(s)! Your enrollment is now confirmed and you can start learning right away.</p>
        ${
        password !== null && password !== undefined && password !== ''
          ? `
          <p>Your login details are as follows:</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Password:</strong> ${password}</p>
          <a href="${process.env.FRONTEND_URL || 'https://edrilla.com'}/login" style="padding: 10px 15px; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">
            Login to your account
          </a>
          `
          : ''
        }
        <p>Once logged in, you can access your enrolled courses from your dashboard and begin your learning journey.</p>
        <p>If you have any questions or need assistance, feel free to contact our support team.</p>
        <hr />
        <p style="font-size: 12px; color: #777;">This is an automated email, please do not reply.</p>
      </div>
      `,
    };

    try {
      const info = await this.getTransporter("transactional").sendMail(mailOptions);
      //console.log("✅ Order confirmation email sent:", info.messageId);
      return { success: true, messageId: info.messageId };
    } catch (error) {
      console.error("❌ Error sending email:", error);
      throw new Error(
        `Failed to send order confirmation email: ${error.message}`
      );
    }
  }

  /**
   * Send event registration email (Founder for event/casual, Transactional if login details)
   * If password is provided, it's a new user, so use transactional. Otherwise, use founder.
   */
  async sendEventRegistrationEmail(email, name, eventDetails, password = null) {
    // If password is present, it's a transactional email (new user), else it's a founder/casual info email
    const fromType = password ? "transactional" : "founder";
    const mailOptions = {
      from: this.getFrom(fromType),
      to: email,
      subject: `Registration Confirmation for ${eventDetails.title}`,
      html: `
        <div style="font-family: Arial, sans-serif; line-height: 1.5;">
          <h2>Event Registration Confirmation</h2>
          <p>Hello <strong>${name}</strong>,</p>
          <p>Thank you for registering for the event: <strong>${eventDetails.title
        }</strong>.</p>
          <p>Event Details:</p>
          <ul>
            <li><strong>Date:</strong> ${eventDetails.startDate}</li>
            <li><strong>Location:</strong> ${eventDetails.venue.address}, ${eventDetails.venue.city
        }, ${eventDetails.venue.country}</li>
          ${eventDetails.onlineLink
          ? `
            <li><strong>Platform:</strong> ${eventDetails.onlineLink.platform
          }</li>
            <li><strong>Meeting URL:</strong> <a href="${eventDetails.onlineLink.url
          }" target="_blank">Join</a></li>
            ${eventDetails.onlineLink.meetingId
            ? `<li><strong>Meeting ID:</strong> ${eventDetails.onlineLink.meetingId}</li>`
            : ""
          }
            ${eventDetails.onlineLink.password
            ? `<li><strong>Password:</strong> ${eventDetails.onlineLink.password}</li>`
            : ""
          }
          `
          : ""
        }
          </ul>
          ${password
          ? `
          <p>Your login details are as follows:</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Password:</strong> ${password}</p>
          `
          : ""
        }
          <p>If you have any questions or need assistance, feel free to contact our support team.</p>
          <hr />
          <p style="font-size: 12px; color: #777;">This is an automated email, please do not reply.</p>
        </div>
      `,
    };

    try {
      const info = await this.getTransporter(fromType).sendMail(mailOptions);
      //console.log("✅ Event registration email sent:", info.messageId);
      return { success: true, messageId: info.messageId };
    } catch (error) {
      console.error("❌ Error sending email:", error);
      throw new Error(
        `Failed to send event registration email: ${error.message}`
      );
    }
  }

  /**
   * Send job proposal email to job creator (job feature is user-to-user, not from Edrilla)
   * This email is sent from the applicant to the job creator, using the applicant's email as the "from" address.
   * Edrilla only relays the email, it is not a proposal to Edrilla.
   */
  async sendJobProposalEmail(jobCreatorEmail, jobCreatorName, jobTitle, proposalDetails, applicant) {
    // applicant: { name, email }
    const attachments = [];
    if (proposalDetails.cv) {
      attachments.push({
        filename: "CV.pdf",
        path: proposalDetails.cv, // Should be a file path or URL accessible to the server
      });
    }

    const mailOptions = {
      from: `"${applicant.name}" <${applicant.email}>`,
      to: jobCreatorEmail,
      subject: `New Proposal for Your Job: "${jobTitle}"`,
      html: `
        <div style="font-family: Arial, sans-serif; line-height: 1.5;">
          <h2>New Proposal for Your Job</h2>
          <p>Hello <strong>${jobCreatorName}</strong>,</p>
          <p><strong>${applicant.name}</strong> has submitted a proposal for your job post: <strong>${jobTitle}</strong>.</p>
          <p><strong>Proposal Details:</strong></p>
          <ul>
            <li><strong>Cover Letter:</strong> ${proposalDetails.coverLetter || "N/A"}</li>
            <li><strong>Proposed Amount:</strong> ${proposalDetails.proposedAmount ? proposalDetails.proposedAmount : "N/A"}</li>
            <li><strong>Status:</strong> ${proposalDetails.status || "pending"}</li>
            <li><strong>Submitted At:</strong> ${proposalDetails.submittedAt ? new Date(proposalDetails.submittedAt).toLocaleString() : "N/A"}</li>
            <li><strong>Applicant Email:</strong> ${applicant.email}</li>
          </ul>
          ${proposalDetails.cv
          ? `<p><strong>CV is attached to this email.</strong></p>`
          : ""
        }
          <p>You can reply directly to this email to contact the applicant.</p>
          <hr />
          <p style="font-size: 12px; color: #777;">This is an automated email, please do not reply.</p>
        </div>
      `,
      attachments,
      replyTo: applicant.email,
    };

    try {
      const info = await this.getTransporter("support").sendMail(mailOptions);
      //console.log("✅ Job proposal email relayed to job creator:", info.messageId);
      return { success: true, messageId: info.messageId };
    } catch (error) {
      console.error("❌ Error relaying job proposal email:", error);
      throw new Error(`Failed to relay job proposal email: ${error.message}`);
    }
  }
}

export default new EmailService();

// /*
// ========================
// Example .env file
// ========================

// # SMTP configuration
// SMTP_HOST=smtp.google.com
// SMTP_PORT=587
// SMTP_SECURE=false

// # Transactional Email (OTP, password reset, order, new user event)
// TransactionalEmail=noreply@edrilla.com
// TransactionalEmailPass=your_noreply_password

// # Founder Email (casual info, update, launch, event info)
// FounderEmail=sahil@edrilla.com
// FounderEmailPass=your_sahil_password

// # Support Email (contact, ticket, support, job proposal)
// SupportEmail=support@edrilla.com
// SupportEmailPass=your_support_password

// # Optional
// FRONTEND_URL=https://edrilla.com

// ========================
// Email Sender Mapping
// ========================

// | Email Type                | From Name         | From Email                | Password Env                | getFrom("type")      |
// |---------------------------|-------------------|---------------------------|-----------------------------|----------------------|
// | Transactional (OTP, reset, order, new user event) | Edrilla           | noreply@edrilla.com         | TransactionalEmailPass      | "transactional"      |
// | Founder/Casual (event info, launch, update) | Sahil (Edrilla)   | sahil@edrilla.com           | FounderEmailPass            | "founder"            |
// | Support (contact, ticket, job proposal) | Edrilla Support   | support@edrilla.com         | SupportEmailPass            | "support"            |
