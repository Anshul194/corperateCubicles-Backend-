const setTokensCookies = (res, accessToken, refreshToken, accessTokenMaxAge, refreshTokenMaxAge) => {
  //console.log("🍪 Setting cookies with maxAge values:", {
    accessTokenMaxAge,
    refreshTokenMaxAge
  });

  if (isNaN(accessTokenMaxAge) || accessTokenMaxAge <= 0) {
    console.error("❌ Invalid access token maxAge:", accessTokenMaxAge);
    throw new Error("Invalid access token expiration time");
  }

  if (isNaN(refreshTokenMaxAge) || refreshTokenMaxAge <= 0) {
    console.error("❌ Invalid refresh token maxAge:", refreshTokenMaxAge);
    throw new Error("Invalid refresh token expiration time");
  }

  res.cookie("accessToken", accessToken, {
    httpOnly: true,
    secure: true,
    maxAge: accessTokenMaxAge, // Already a duration in ms
    sameSite: "lax",
  });

  res.cookie("refreshToken", refreshToken, {
    httpOnly: true,
    secure: true,
    maxAge: refreshTokenMaxAge,
    sameSite: "lax",
  });

  res.cookie("is_auth", true, {
    httpOnly: false,
    secure: true,
    maxAge: refreshTokenMaxAge,
    sameSite: "lax",
  });
};

export { setTokensCookies };